import io
import json
import sys
import unittest
from pathlib import Path
from unittest import mock

ROOT = Path(__file__).resolve().parent.parent
sys.path.insert(0, str(ROOT))

from PIL import Image, ImageDraw, ImageFilter, ImageFont  # noqa: E402

import app as webapp  # noqa: E402
from screener import analyze_writing, check_resume, role_match, tesseract_available  # noqa: E402
from screener.builder import build_docx, clean_resume, draft_from_prompt  # noqa: E402
from screener.ocr import parse_tsv  # noqa: E402
from screener.parser import read_resume  # noqa: E402

DATA = ROOT / "sample_data" / "checker"
GOOD = (DATA / "good_resume.txt").read_text()
WEAK = (DATA / "weak_resume.txt").read_text()


def render_photo(text, size=22, blur=0, width=1500):
    """A picture of a resume, like a phone photo or screenshot, for OCR tests."""
    try:
        font = ImageFont.truetype("DejaVuSans.ttf", size)
    except OSError:
        font = ImageFont.load_default()
    img = Image.new("RGB", (width, 1700), "white")
    d = ImageDraw.Draw(img)
    y = 40
    for line in text.splitlines():
        d.text((50, y), line, fill="black", font=font)
        y += size + 12
    if blur:
        img = img.filter(ImageFilter.GaussianBlur(blur))
    buf = io.BytesIO()
    img.save(buf, "PNG")
    return buf.getvalue()


class CheckerTests(unittest.TestCase):
    def test_good_resume_scores_high_and_weak_scores_low(self):
        good = check_resume(GOOD, {"ext": ".txt"})
        weak = check_resume(WEAK, {"ext": ".txt"})
        self.assertGreaterEqual(good["score"], 85)
        self.assertLess(weak["score"], 40)
        self.assertEqual(sum(c["max"] for c in good["checks"]), 100)

    def test_missing_email_is_flagged(self):
        r = check_resume(GOOD.replace("meera.joshi@example.com", ""), {"ext": ".txt"})
        self.assertEqual(next(c for c in r["checks"] if c["id"] == "email")["status"], "fail")

    def test_photo_and_scan_get_a_file_type_warning(self):
        r = check_resume(GOOD, {"ext": ".photo"})
        self.assertEqual(next(c for c in r["checks"] if c["id"] == "filetype")["status"], "warn")

    def test_role_match_and_job_post_match(self):
        m = role_match(GOOD, "data-analyst")
        self.assertIn("sql", m["matched"])
        self.assertIn("data visualization", m["matched"])  # Power BI / Tableau count
        weak = role_match("I like computers.", "data-analyst")
        self.assertIn("data visualization", weak["missing"])
        jd = role_match(GOOD, "", "We need Python, SQL, Docker and Kubernetes.", "Acme")
        self.assertIn("docker", jd["missing"])
        self.assertEqual(jd["source"], "job_description")


class WritingTests(unittest.TestCase):
    def test_buzzwords_are_found(self):
        w = analyze_writing(WEAK)
        names = [p["phrase"] for p in w["phrases"]]
        self.assertIn("results-driven", names)
        self.assertIn("proven track record", names)
        self.assertNotEqual(w["label"], "Reads naturally")

    def test_clean_resume_reads_naturally(self):
        self.assertEqual(analyze_writing(GOOD)["label"], "Reads naturally")

    def test_simple_rewrite(self):
        text = "- Utilized robust tools to build a report\n- Built a login page\n- Fixed 4 bugs in the API\n- Wrote tests for the parser"
        w = analyze_writing(text)
        self.assertEqual(w["rewrites"][0]["suggested"], "Used reliable tools to build a report")

    def test_it_does_not_claim_to_detect_ai(self):
        self.assertIn("not an AI detector", analyze_writing(WEAK)["note"])


class BuilderTests(unittest.TestCase):
    def test_docx_round_trip_has_no_tables_or_images(self):
        data = draft_from_prompt("My name is Ravi Kumar, B.Tech student. I know Python, Flask, SQL and Git. Data analyst role. ravi@example.com 9876543210")
        self.assertEqual(data["name"], "Ravi Kumar")
        self.assertIn("Git", data["skills"][0]["items"])
        doc = read_resume("r.docx", build_docx(data))
        self.assertIn("ravi@example.com", doc["text"])
        self.assertEqual(doc["info"]["tables"], 0)
        self.assertEqual(doc["info"]["images"], 0)

    def test_clean_resume_limits_and_ignores_junk(self):
        r = clean_resume({"name": "x" * 500, "skills": "not a list", "experience": [{"role": "A", "bullets": ["b"] * 50}], "projects": "bad"})
        self.assertEqual(len(r["name"]), 80)
        self.assertEqual(r["skills"], [])
        self.assertEqual(len(r["experience"][0]["bullets"]), 6)
        self.assertEqual(r["projects"], [])


class OcrTests(unittest.TestCase):
    def test_tsv_parser(self):
        tsv = ("level\tpage_num\tblock_num\tpar_num\tline_num\tword_num\tleft\ttop\twidth\theight\tconf\ttext\n"
               "5\t1\t1\t1\t1\t1\t0\t0\t1\t1\t96\tHello\n5\t1\t1\t1\t1\t2\t0\t0\t1\t1\t90\tworld\n"
               "5\t1\t1\t1\t2\t1\t0\t0\t1\t1\t-1\t\n")
        out = parse_tsv(tsv)
        self.assertEqual(out["text"], "Hello world")
        self.assertEqual(out["confidence"], 93)


class AppTests(unittest.TestCase):
    def setUp(self):
        self.c = webapp.app.test_client()

    def post_file(self, url, name, data, **fields):
        form = {"resume": (io.BytesIO(data), name), **fields}
        return self.c.post(url, data=form, content_type="multipart/form-data")

    def test_pages_load(self):
        for url in ["/", "/check", "/build", "/recruiter", "/guide"]:
            self.assertEqual(self.c.get(url).status_code, 200, url)
        self.assertEqual(self.c.get("/nope").status_code, 404)
        self.assertEqual(self.c.get("/api/nope").status_code, 404)

    def test_meta_and_health(self):
        self.assertTrue(len(self.c.get("/api/meta").json["roles"]) >= 5)
        self.assertEqual(self.c.get("/api/health").json["status"], "ok")

    def test_check_txt(self):
        r = self.post_file("/api/check", "good.txt", GOOD.encode(), role="data-analyst", company="Acme")
        self.assertEqual(r.status_code, 200)
        j = r.json
        self.assertGreaterEqual(j["report"]["score"], 85)
        self.assertEqual(j["source"], "text")
        self.assertIn("match", j)
        self.assertIsNone(j["scan"])

    def test_check_docx_built_by_the_site(self):
        data = draft_from_prompt("My name is Asha Patil, B.Tech student. I know Python, SQL, Flask and Git. Data analyst role. asha@example.com 9876543210")
        r = self.post_file("/api/check", "a.docx", build_docx(data))
        self.assertEqual(r.status_code, 200, r.json)
        self.assertEqual(r.json["source"], "text")

    def test_check_errors(self):
        self.assertEqual(self.c.post("/api/check", data={}, content_type="multipart/form-data").status_code, 400)
        self.assertEqual(self.post_file("/api/check", "x.exe", b"abc").status_code, 400)
        self.assertEqual(self.post_file("/api/check", "tiny.txt", b"hello").status_code, 400)
        self.assertEqual(self.post_file("/api/check", "bad.pdf", b"not a pdf at all").status_code, 400)

    @unittest.skipUnless(tesseract_available(), "Tesseract is not installed")
    def test_check_photo_is_read_by_ocr(self):
        r = self.post_file("/api/check", "photo.png", render_photo(GOOD))
        self.assertEqual(r.status_code, 200, r.json)
        j = r.json
        self.assertEqual(j["source"], "photo")
        self.assertIn("meera.joshi@example.com", j["extracted_text"])
        self.assertGreater(j["scan"]["confidence"], 70)
        ft = next(c for c in j["report"]["checks"] if c["id"] == "filetype")
        self.assertEqual(ft["status"], "warn")

    @unittest.skipUnless(tesseract_available(), "Tesseract is not installed")
    def test_blurry_and_small_photos_get_warnings(self):
        r = self.post_file("/api/check", "blur.png", render_photo(GOOD, blur=4))
        warnings = " ".join(r.json["scan"]["warnings"]) if r.status_code == 200 else r.json["error"]
        self.assertTrue("blurry" in warnings or "hard to read" in warnings or r.status_code == 400, warnings)
        small = self.post_file("/api/check", "small.png", render_photo(GOOD, size=12, width=700))
        text = " ".join(small.json.get("scan", {}).get("warnings", [])) if small.status_code == 200 else small.json["error"]
        self.assertIn("small", text + " small") # small photos either warn or fail clearly, never crash

    def test_rank_blind_and_quality(self):
        files = [(io.BytesIO(GOOD.encode()), "=cmd_good.txt"), (io.BytesIO(WEAK.encode()), "weak.txt")]
        jd = "Data analyst needing Python, SQL, pandas and Power BI."
        r = self.c.post("/api/rank", data={"job_description": jd, "blind": "1", "resumes": files}, content_type="multipart/form-data")
        self.assertEqual(r.status_code, 200)
        j = r.json
        self.assertEqual(j["ranking"][0]["name"], "Candidate 1")
        self.assertEqual(j["ranking"][0]["filename"], "hidden")
        self.assertIn("quality", j["ranking"][0])
        self.assertIn("python", j["ranking"][0]["skills_matched"])
        self.assertLess(j["ranking"][1]["quality"]["score"], j["ranking"][0]["quality"]["score"])

    def test_rank_limits(self):
        many = [(io.BytesIO(GOOD.encode()), f"r{i}.txt") for i in range(16)]
        r = self.c.post("/api/rank", data={"job_description": "python", "resumes": many}, content_type="multipart/form-data")
        self.assertEqual(r.status_code, 400)

    def test_builder_routes_and_script_injection(self):
        evil = {"name": "<script>alert(1)</script>", "email": "a@b.co", "summary": "Hi [add detail]"}
        html = self.c.post("/api/build/preview", json={"resume": evil, "style": "fresher"}).json["html"]
        self.assertNotIn("<script>", html)
        self.assertIn("&lt;script&gt;", html)
        self.assertIn('class="todo"', html)
        d = self.c.post("/api/build/docx", json={"resume": evil})
        self.assertEqual(d.status_code, 200)
        self.assertIn("attachment", d.headers["Content-Disposition"])
        self.assertTrue(d.data.startswith(b"PK"))

    def test_basic_draft_needs_enough_text(self):
        self.assertEqual(self.c.post("/api/build/draft", json={"prompt": "hi"}).status_code, 400)
        ok = self.c.post("/api/build/draft", json={"prompt": "My name is Ravi Kumar and I know Python and SQL, B.Tech 2027."})
        self.assertEqual(ok.json["mode"], "basic")

    def test_ai_features_without_a_key(self):
        with mock.patch.dict("os.environ", {"ANTHROPIC_API_KEY": ""}):
            r = self.c.post("/api/build/draft", json={"prompt": "My name is Ravi Kumar and I know Python.", "use_ai": True})
            self.assertEqual(r.status_code, 503)
            r = self.c.post("/api/ai/improve", json={"text": "Utilized robust solutions to deliver results."})
            self.assertEqual(r.status_code, 503)

    def test_ai_draft_with_mocked_reply(self):
        reply = json.dumps({"name": "Ravi Kumar", "email": "ravi@example.com", "summary": "Student with Python skills.",
                            "skills": [{"label": "Languages", "items": ["Python"]}],
                            "projects": [{"name": "Notes app", "tech": "Flask", "bullets": ["Built a notes API with 4 endpoints."]}]})
        with mock.patch.dict("os.environ", {"ANTHROPIC_API_KEY": "test-key"}), mock.patch("screener.ai._call", return_value="Here you go:\n" + reply):
            r = self.c.post("/api/build/draft", json={"prompt": "My name is Ravi Kumar and I know Python. Project: notes app.", "use_ai": True})
            self.assertEqual(r.status_code, 200, r.json)
            self.assertEqual(r.json["mode"], "ai")
            self.assertEqual(r.json["resume"]["projects"][0]["name"], "Notes app")
            r2 = self.c.post("/api/ai/improve", json={"text": "Utilized robust solutions to deliver results quickly."})
            self.assertEqual(r2.status_code, 200)

    def test_ai_rate_limit(self):
        from screener import ai
        ai._by_client.clear()
        with mock.patch.dict("os.environ", {"ANTHROPIC_API_KEY": "k", "AI_LIMIT_PER_HOUR": "2"}), mock.patch("screener.ai._call", return_value="ok text here for rewriting"):
            codes = [self.c.post("/api/ai/improve", json={"text": "Utilized robust solutions to deliver results."}).status_code for _ in range(3)]
        self.assertEqual(codes, [200, 200, 429])
        ai._by_client.clear()

    def test_too_large_file_is_rejected(self):
        big = b"a" * (13 * 1024 * 1024)
        self.assertEqual(self.post_file("/api/check", "big.txt", big).status_code, 413)


if __name__ == "__main__":
    unittest.main()
