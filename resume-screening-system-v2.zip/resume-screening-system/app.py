"""Resume Screener website and REST API.

Pages:  /  /check  /build  /recruiter  /guide
API:    /api/check  /api/rank  /api/build/draft  /api/build/preview  /api/build/docx
        /api/ai/improve  /api/meta  /api/health

Privacy: uploaded files are read in memory and never saved to disk or a database.
"""
import io
import os

import re

from flask import Flask, jsonify, render_template, request, send_file
from markupsafe import Markup, escape

from screener import (OcrUnavailable, analyze_writing, check_resume, guess_candidate_name, rank_resumes,
                      read_resume, role_match, tesseract_available)
from screener import ai
from screener.builder import build_docx, clean_resume, contact_line, draft_from_prompt, layout
from screener.parser import ALLOWED_EXTENSIONS
from screener.preprocess import BACKEND
from screener.profiles import ROLE_LIST

app = Flask(__name__)
app.config["MAX_CONTENT_LENGTH"] = 40 * 1024 * 1024  # whole request
MAX_FILE_BYTES = 12 * 1024 * 1024                       # one resume or photo
MAX_RANK_FILES = 15


@app.template_filter("brackets")
def brackets(value):
    """Escape text, then highlight [placeholders] so people notice what is still to fill in."""
    return Markup(re.sub(r"\[[^\]]{1,80}\]", lambda m: f'<mark class="todo">{m.group(0)}</mark>', str(escape(value))))


def err(message, status=400, **extra):
    return jsonify(error=message, **extra), status


@app.errorhandler(413)
def too_big(_):
    return err("That upload is too large. Keep each file under 12 MB.", 413)


@app.errorhandler(404)
def not_found(_):
    if request.path.startswith("/api/"):
        return err("Not found.", 404)
    return render_template("notfound.html", page=""), 404


# ------------------------------------------------------------------ pages
@app.get("/")
def home():
    return render_template("home.html", page="home")


@app.get("/favicon.ico")
def favicon():
    return "", 204


@app.get("/check")
def check_page():
    return render_template("check.html", page="check")


@app.get("/build")
def build_page():
    return render_template("build.html", page="build")


@app.get("/recruiter")
def recruiter_page():
    return render_template("recruiter.html", page="recruiter")


@app.get("/guide")
def guide_page():
    return render_template("guide.html", page="guide")


# ------------------------------------------------------------------ small API
@app.get("/api/health")
def health():
    return jsonify(status="ok", nlp_backend=BACKEND, photo_reading=tesseract_available(), ai=ai.ai_enabled())


@app.get("/api/meta")
def meta():
    return jsonify(roles=ROLE_LIST, photo_reading=tesseract_available(), ai=ai.ai_enabled())


def _read_upload(f):
    """Read one uploaded file. Returns (doc, error_response)."""
    ext = os.path.splitext(f.filename or "")[1].lower()
    if ext not in ALLOWED_EXTENSIONS:
        return None, err("Use a PDF, DOCX, TXT, or a JPG/PNG photo.")
    data = f.read()
    if len(data) > MAX_FILE_BYTES:
        return None, err("That file is larger than 12 MB.", 413)
    try:
        return read_resume(f.filename, data), None
    except OcrUnavailable as exc:
        return None, err(str(exc) + " Upload a PDF or DOCX instead.", 503)
    except ValueError as exc:
        return None, err(str(exc))
    except Exception:
        return None, err("This file could not be read. It may be damaged or password protected.")


# ------------------------------------------------------------------ checker
@app.post("/api/check")
def api_check():
    f = request.files.get("resume")
    if f is None or not f.filename:
        return err("Choose a resume file first.")
    doc, bad = _read_upload(f)
    if bad:
        return bad
    text = doc["text"]
    if len(text.split()) < 20:
        hint = ("Retake the photo in good light with the whole page in view."
                if doc["source"] == "photo" else
                "If this is a scanned PDF, upload a clearer scan or the original file.")
        return err("Almost no text could be read from this file. " + hint)

    jd = (request.form.get("job_description") or "")[:20000]
    role = request.form.get("role") or ""
    company = (request.form.get("company") or "").strip()[:80]

    scan = doc["scan"]
    return jsonify(
        file=f.filename,
        source=doc["source"],
        report=check_resume(text, doc["info"]),
        match=role_match(text, role, jd, company),
        writing=analyze_writing(text),
        scan=({"confidence": scan["confidence"], "warnings": scan["warnings"]} if scan else None),
        extracted_text=text[:8000],
    )


# ------------------------------------------------------------------ recruiter ranking
@app.post("/api/rank")
def rank():
    """multipart/form-data: job_description (text), resumes (files), blind ('1' hides names)."""
    jd = request.form.get("job_description", "").strip()
    files = [f for f in request.files.getlist("resumes") if f.filename]
    blind = request.form.get("blind") == "1"

    if not jd:
        return err("Please provide a job description.")
    if not files:
        return err("Please upload at least one resume.")
    if len(files) > MAX_RANK_FILES:
        return err(f"Please upload at most {MAX_RANK_FILES} resumes at a time.")

    resumes, skipped = [], []
    for i, f in enumerate(files, start=1):
        doc, bad = _read_upload(f)
        if bad:
            skipped.append({"file": f.filename, "reason": bad[0].get_json()["error"]})
            continue
        if not doc["text"].strip():
            skipped.append({"file": f.filename, "reason": "no readable text"})
            continue
        quality = check_resume(doc["text"], doc["info"])
        resumes.append({
            "name": f"Candidate {i}" if blind else guess_candidate_name(doc["text"], f.filename),
            "filename": "hidden" if blind else f.filename,
            "text": doc["text"],
            "quality": {
                "score": quality["score"],
                "label": quality["label"],
                "issues": [c["title"] for c in quality["checks"] if c["status"] == "fail"][:4],
                "from_photo": doc["source"] != "text",
            },
        })

    if not resumes:
        return err("No readable resumes were found.", 400, skipped=skipped)

    ranking = rank_resumes(jd, resumes)
    by_key = {(r["name"], r["filename"]): r["quality"] for r in resumes}
    for item in ranking:
        item["quality"] = by_key.get((item["name"], item["filename"]))
    return jsonify(count=len(ranking), ranking=ranking, skipped=skipped, blind=blind)


# ------------------------------------------------------------------ resume builder
def _client_id():
    fwd = request.headers.get("X-Forwarded-For", "")
    return (fwd.split(",")[0].strip() if fwd else request.remote_addr) or "unknown"


@app.post("/api/build/draft")
def build_draft():
    body = request.get_json(silent=True) or {}
    prompt = str(body.get("prompt") or "").strip()[:4000]
    style = "experienced" if body.get("style") == "experienced" else "fresher"
    use_ai = bool(body.get("use_ai"))
    if len(prompt) < 15:
        return err("Describe yourself in a few lines: your name, studies, skills and projects.")
    if use_ai:
        try:
            ai.check_limit(_client_id())
            data = clean_resume(ai.generate_resume(prompt, style))
            return jsonify(resume=data, mode="ai")
        except ai.RateLimited as exc:
            return err(str(exc), 429)
        except ai.AIUnavailable as exc:
            return err(str(exc) + " Use basic draft instead.", 503)
        except ai.AIError as exc:
            return err(str(exc), 502)
    return jsonify(resume=draft_from_prompt(prompt), mode="basic")


@app.post("/api/build/preview")
def build_preview():
    body = request.get_json(silent=True) or {}
    r = clean_resume(body.get("resume"))
    style = "experienced" if body.get("style") == "experienced" else "fresher"
    html = render_template("resume_preview.html", r=r, contact=contact_line(r), sections=layout(r, style))
    return jsonify(html=html)


@app.post("/api/build/docx")
def build_docx_route():
    body = request.get_json(silent=True) or {}
    r = clean_resume(body.get("resume"))
    style = "experienced" if body.get("style") == "experienced" else "fresher"
    safe = "".join(c for c in (r["name"] or "resume") if c.isalnum() or c in " _-").strip().replace(" ", "_") or "resume"
    return send_file(
        io.BytesIO(build_docx(r, style)), as_attachment=True, download_name=f"{safe}_resume.docx",
        mimetype="application/vnd.openxmlformats-officedocument.wordprocessingml.document",
    )


@app.post("/api/ai/improve")
def ai_improve():
    body = request.get_json(silent=True) or {}
    text = str(body.get("text") or "").strip()[:6000]
    if len(text) < 20:
        return err("Paste a few lines of your resume to rewrite.")
    try:
        ai.check_limit(_client_id())
        return jsonify(text=ai.improve_text(text))
    except ai.RateLimited as exc:
        return err(str(exc), 429)
    except ai.AIUnavailable as exc:
        return err(str(exc), 503)
    except ai.AIError as exc:
        return err(str(exc), 502)


if __name__ == "__main__":
    # Local / Codespaces: python app.py   (set FLASK_DEBUG=1 for auto-reload)
    # Production (Docker / Render / Hugging Face) uses gunicorn instead, see Dockerfile.
    port = int(os.environ.get("PORT", 5000))
    app.run(host="0.0.0.0", port=port, debug=os.environ.get("FLASK_DEBUG") == "1")
