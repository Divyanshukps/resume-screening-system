# Update guide (Project 1: Resume Screener)

## 1. Replace files on GitHub
Extract the zip. Upload everything, replacing old files (GitHub: Add file > Upload files, drag the folder contents, Commit).
Delete the old `templates/index.html` on GitHub.

New files: screener/{writing,ocr,builder,ai}.py, templates/{check,build,recruiter,guide,notfound,resume_preview}.html,
static/{common,check,build,recruiter}.js, sample_data/checker/, tests/test_features.py
Changed: app.py, Dockerfile, requirements.txt, README.md, static/style.css, templates/{base,home}.html,
screener/{__init__,checker,parser,preprocess,ranker,profiles}.py

## 2. Test in Codespaces
    sudo apt-get update && sudo apt-get install -y tesseract-ocr
    pip install -r requirements.txt
    python -m unittest discover -s tests -v     # expect 28 OK
    python app.py                               # open the forwarded port

## 3. Deploy
Render: New > Web Service > connect repo > Runtime Docker > Free. PORT is automatic.
Hugging Face: Docker Space, upload same files (port 7860).

## 4. Optional AI (resume writing + rewrite buttons)
Set environment variables on the host: ANTHROPIC_API_KEY (required), AI_MODEL, AI_LIMIT_PER_HOUR (8), AI_LIMIT_PER_DAY (300).
Without a key the site still works with the basic draft.
