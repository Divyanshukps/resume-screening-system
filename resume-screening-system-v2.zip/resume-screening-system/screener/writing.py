"""Plain-language check: generic wording, repeated patterns, and simpler rewrites.

IMPORTANT: this is NOT an AI detector. No tool can prove who or what wrote a text, and
detectors wrongly flag people who write in a second language. These are style signals that
make a resume sound like a template. Use them to improve the writing, never to accuse anyone.
"""
import re
from collections import Counter
from statistics import pstdev

from .checker import BULLET_RE, heading_key

# phrase -> plain replacement. "" means: cut it, or replace it with a real example.
REPLACEMENTS = {
    "results-driven": "", "results-oriented": "", "detail-oriented": "careful", "dynamic": "",
    "passionate about": "interested in", "passionate": "keen", "proven track record": "",
    "team player": "", "hard-working": "", "hardworking": "", "self-motivated": "", "go-getter": "",
    "fast-paced environment": "", "cutting-edge": "modern", "state-of-the-art": "modern",
    "innovative": "", "seamlessly": "", "robust": "reliable", "synergy": "teamwork",
    "synergies": "teamwork", "spearheaded": "led", "orchestrated": "organized", "leveraged": "used",
    "leveraging": "using", "leverage": "use", "utilized": "used", "utilizing": "using",
    "utilize": "use", "in order to": "to", "a wide range of": "many", "delved into": "looked into",
    "delve into": "look into", "showcasing": "showing", "fostering": "building", "holistic": "",
    "multifaceted": "", "tapestry": "", "think outside the box": "", "extensive experience": "",
    "strong foundation": "", "highly motivated": "", "excellent communication skills": "",
}
_PATTERN = re.compile(
    r"(?<![\w-])(" + "|".join(re.escape(p) for p in sorted(REPLACEMENTS, key=len, reverse=True)) + r")(?![\w-])",
    re.I,
)
PASSIVE_RE = re.compile(r"\b(?:was|were|been)\s+\w+ed\b", re.I)

NOTE = ("This is a writing-style check, not an AI detector. Nobody can prove who or what wrote a text, "
        "and real detectors often flag people who write in a second language. Use it to make your resume "
        "sound more like you, not to judge anyone.")


def _words(s):
    return re.findall(r"[A-Za-z0-9+#']+", s)


def statements_of(text: str) -> list:
    lines = [l.strip() for l in text.splitlines() if l.strip()]
    marked = [BULLET_RE.match(l).group(1) for l in lines if BULLET_RE.match(l)]
    if len(marked) >= 3:
        return marked
    return [l for l in lines if len(_words(l)) >= 6 and not heading_key(l)]


def _rewrite(line: str):
    found = [m.group(0) for m in _PATTERN.finditer(line)]
    if not found or any(REPLACEMENTS[f.lower()] == "" for f in found):
        return None  # cutting a phrase out can leave a broken sentence, so no automatic rewrite

    def sub(m):
        rep = REPLACEMENTS[m.group(0).lower()]
        return rep[:1].upper() + rep[1:] if m.group(0)[:1].isupper() else rep

    new = _PATTERN.sub(sub, line)
    return new if new != line else None


def analyze_writing(text: str) -> dict:
    statements = statements_of(text)
    n_words = max(len(_words(text)), 1)

    hits = Counter(m.group(0).lower() for m in _PATTERN.finditer(text))
    total_hits = sum(hits.values())
    density = total_hits * 100 / n_words

    signals, score = [], 0

    def add(level, title, detail, tip, points):
        nonlocal score
        score += points
        signals.append({"level": level, "title": title, "detail": detail, "tip": tip})

    if total_hits:
        listing = ", ".join(f"{p} ({c})" if c > 1 else p for p, c in hits.most_common(8))
        pts = 45 if density >= 3 else 30 if density >= 1.5 else 18 if density >= 0.7 else 8
        add("warn" if pts > 8 else "info", "Buzzwords and filler", f"Found: {listing}.",
            "Swap each one for a plain word or a real example of what you did.", pts)

    if len(statements) >= 4:
        starts = Counter((_words(s) or [""])[0].lower() for s in statements)
        word, count = starts.most_common(1)[0]
        share = count / len(statements)
        if count >= 3 and share >= 0.5:
            add("warn", "Same opening word", f"{count} of {len(statements)} points start with '{word}'.",
                "Vary the first word: Built, Designed, Tested, Fixed, Presented.", 20)
        elif count >= 3 and share >= 0.35:
            add("info", "Repeated opening word", f"{count} of {len(statements)} points start with '{word}'.",
                "Change a few openings so the list reads less like a pattern.", 10)

    if len(statements) >= 6:
        lengths = [len(_words(s)) for s in statements]
        if pstdev(lengths) <= 3.0:
            add("info", "Every point is the same length", f"Points are all about {round(sum(lengths) / len(lengths))} words long.",
                "Real writing varies. Let a simple point be short and a complex one longer.", 10)
        if sum(lengths) / len(lengths) > 28:
            add("warn", "Very long points", f"Points average {round(sum(lengths) / len(lengths))} words.",
                "Keep each point to one idea, around 12 to 22 words.", 8)
        if not any(re.search(r"\d", s) for s in statements):
            add("info", "No specific numbers", "No point contains a number.",
                "One real number (users, accuracy, hours saved) makes a point sound like you.", 10)

    dashes = text.count("—")
    if dashes >= 3:
        add("info", "Many long dashes", f"Found {dashes} long dashes.", "Use commas or full stops instead.", 10)

    passive = len(PASSIVE_RE.findall(text))
    if passive >= 3:
        add("info", "Passive wording", f"Found {passive} passive phrases such as 'was developed'.",
            "Say who did it: 'Developed the login page'.", 8)

    score = min(score, 100)
    label = "Heavy template-like language" if score >= 50 else "Some template-like language" if score >= 25 else "Reads naturally"

    rewrites = []
    for s in statements:
        new = _rewrite(s)
        if new:
            rewrites.append({"original": s, "suggested": new})
        if len(rewrites) >= 8:
            break

    return {
        "score": score,
        "label": label,
        "signals": signals,
        "phrases": [{"phrase": p, "count": c, "plain": REPLACEMENTS[p] or None} for p, c in hits.most_common()],
        "rewrites": rewrites,
        "note": NOTE,
    }
