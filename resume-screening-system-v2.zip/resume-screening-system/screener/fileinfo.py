"""Facts about the uploaded file itself (pages, tables, images), used by the format checks."""
import io
from pathlib import Path


def file_info(filename: str, data: bytes) -> dict:
    ext = Path(filename).suffix.lower()
    info = {"ext": ext, "pages": None, "tables": 0, "images": 0, "bullets": 0}
    try:
        if ext == ".pdf":
            import pdfplumber

            with pdfplumber.open(io.BytesIO(data)) as pdf:
                info["pages"] = len(pdf.pages)
                info["images"] = sum(len(p.images) for p in pdf.pages)
        elif ext == ".docx":
            from docx import Document

            doc = Document(io.BytesIO(data))
            info["tables"] = len(doc.tables)
            info["images"] = len(doc.inline_shapes)
            info["bullets"] = sum(
                1
                for p in doc.paragraphs
                if "list" in (p.style.name or "").lower()
                or p._p.pPr is not None and p._p.pPr.numPr is not None
            )
    except Exception:
        pass  # a broken or unusual file just gets fewer format checks
    return info
