"""Rule-based resume checker: how professional and ATS-friendly is this resume?

These are heuristics based on common recruiter and ATS advice. They are NOT an official
verdict from any company or ATS, and a score is a guide for improving, not a guarantee.
"""
import re

from .profiles import ROLE_PROFILES, find_skills

SECTION_PATTERNS = {
    "summary": r"(summary|objective|profile|about me|career objective|professional summary)",
    "education": r"(education|academics?|academic background|qualifications?)",
    "skills": r"(skills?|technical skills|key skills|core competenc\w+|technologies|tech stack)",
    "projects": r"(projects?|academic projects?|personal projects?)",
    "experience": r"(experience|work experience|internships?|internship experience|employment|professional experience|work history)",
    "extras": r"(achievements?|certifications?|certificates?|awards?|extracurriculars?|extra curricular activities|activities|positions? of responsibility|publications?)",
}
SECTION_RES = {k: re.compile(v) for k, v in SECTION_PATTERNS.items()}

ACTION_VERBS = {
    "achieved", "analyzed", "analysed", "architected", "automated", "built", "collaborated",
    "created", "cut", "delivered", "deployed", "designed", "developed", "drove", "engineered",
    "established", "executed", "exposed", "handled", "implemented", "improved", "increased",
    "integrated", "launched", "led", "maintained", "managed", "migrated", "optimized", "optimised",
    "organized", "organised", "owned", "planned", "produced", "reduced", "refactored", "researched",
    "resolved", "scaled", "shipped", "simplified", "solved", "streamlined", "trained", "tuned",
    "wrote", "tested", "debugged", "documented", "presented", "mentored", "coordinated", "applied",
    "evaluated", "extracted", "generated", "processed", "published", "won", "ran", "set",
}

WEAK_PHRASES = [
    "responsible for", "hard working", "hardworking", "team player", "go-getter", "self-motivated",
    "detail oriented", "detail-oriented", "results-oriented", "references available",
    "references on request", "challenging position", "challenging role", "fast learner",
    "quick learner", "jack of all trades", "think outside the box",
]

BULLET_RE = re.compile(r"^\s*[•▪◦●·➢►‣⁃*\-–—]\s*(\S.*)$")
EMAIL_RE = re.compile(r"[\w.+-]+@[\w-]+\.[\w.-]+")
MONTHS = r"(jan|feb|mar|apr|may|jun|jul|aug|sep|sept|oct|nov|dec)[a-z]*\.?"
DATE_NAME_RE = re.compile(MONTHS + r"\s+(19|20)\d{2}", re.I)
DATE_NUM_RE = re.compile(r"\b\d{1,2}[/-](19|20)\d{2}\b")


def _words(s):
    return re.findall(r"[A-Za-z0-9+#']+", s)


def heading_key(line: str):
    s = re.sub(r"[^A-Za-z& /]", " ", line).strip().lower()
    s = re.sub(r"\s+", " ", s)
    if not s or len(s.split()) > 4:
        return None
    for key, pat in SECTION_RES.items():
        if pat.fullmatch(s):
            return key
    return None


def split_sections(lines):
    sections = {"header": []}
    current = "header"
    for line in lines:
        key = heading_key(line)
        if key:
            current = key
            sections.setdefault(current, [])
            continue
        sections[current].append(line)
    return sections


def _find_phone(text):
    for cand in re.findall(r"\+?\d[\d\s\-]{8,}\d", text):
        groups = re.findall(r"\d+", cand)
        digits = sum(len(g) for g in groups)
        if all(len(g) == 4 and g[:2] in ("19", "20") for g in groups):
            continue  # a run of years, not a phone number
        if 10 <= digits <= 13:
            return True
    return False


def _check(cid, group, title, status, points, maximum, detail, tip=""):
    return {
        "id": cid, "group": group, "title": title, "status": status,
        "points": points, "max": maximum, "detail": detail, "tip": tip,
    }


def check_resume(text: str, info: dict = None) -> dict:
    info = info or {}
    lines = [l.strip() for l in text.splitlines() if l.strip()]
    sections = split_sections(lines)
    found_sections = [k for k in sections if k != "header" and sections[k] is not None]
    low = text.lower()
    words = len(_words(text))
    checks = []

    # ---- Contact (15)
    has_email = bool(EMAIL_RE.search(text))
    checks.append(_check(
        "email", "Contact", "Email address", "pass" if has_email else "fail", 5 if has_email else 0, 5,
        "Email found." if has_email else "No email address found.",
        "" if has_email else "Add a professional email (name-based, no nicknames)."))
    has_phone = _find_phone(text)
    checks.append(_check(
        "phone", "Contact", "Phone number", "pass" if has_phone else "fail", 5 if has_phone else 0, 5,
        "Phone number found." if has_phone else "No phone number found.",
        "" if has_phone else "Add a phone number recruiters can call."))
    has_links = bool(re.search(r"linkedin\.com/|github\.com/", low))
    mentions = ("linkedin" in low) or ("github" in low)
    if has_links:
        checks.append(_check("links", "Contact", "LinkedIn / GitHub link", "pass", 5, 5, "Profile link found."))
    elif mentions:
        checks.append(_check(
            "links", "Contact", "LinkedIn / GitHub link", "warn", 2, 5,
            "LinkedIn or GitHub is mentioned, but no full link was found in the text.",
            "Write the full URL (for example github.com/yourname) so ATS and humans can click it."))
    else:
        checks.append(_check(
            "links", "Contact", "LinkedIn / GitHub link", "fail", 0, 5, "No LinkedIn or GitHub link.",
            "Add your GitHub and LinkedIn links. Recruiters for tech roles look at projects."))

    # ---- Structure (20)
    def section_check(cid, title, key, pts, tip, alt=None):
        ok = key in found_sections or (alt and alt in found_sections)
        checks.append(_check(cid, "Structure", title, "pass" if ok else "fail", pts if ok else 0, pts,
                             f"{title} section found." if ok else f"No {title.lower()} section found.",
                             "" if ok else tip))
    section_check("education", "Education", "education", 5, "Add an Education section with degree, college and years.")
    section_check("skills", "Skills", "skills", 5, "Add a Skills section listing your tools and languages.")
    ok_pe = "projects" in found_sections or "experience" in found_sections
    checks.append(_check(
        "proj_exp", "Structure", "Projects or Experience", "pass" if ok_pe else "fail", 5 if ok_pe else 0, 5,
        "Projects or experience section found." if ok_pe else "No projects or experience section found.",
        "" if ok_pe else "Add your best 2-3 projects or any internship. This is what recruiters read first."))
    ok_sum = "summary" in found_sections
    checks.append(_check(
        "summary", "Structure", "Short summary", "pass" if ok_sum else "warn", 3 if ok_sum else 1, 3,
        "Summary found." if ok_sum else "No summary or objective section.",
        "" if ok_sum else "Add 2 lines: your target role, your main skills and one strength."))
    ok_ex = "extras" in found_sections
    checks.append(_check(
        "extras", "Structure", "Achievements or certifications", "pass" if ok_ex else "warn", 2 if ok_ex else 1, 2,
        "Achievements or certifications found." if ok_ex else "No achievements or certifications section.",
        "" if ok_ex else "Add certificates, awards or competitions if you have them."))

    # ---- Content
    # statements = the lines that describe what you did
    marker_lines = [BULLET_RE.match(l).group(1) for l in lines if BULLET_RE.match(l)]
    pool = sections.get("experience", []) + sections.get("projects", [])
    if len(marker_lines) >= 3:
        statements = marker_lines
    else:
        source = pool or [l for l in lines if len(_words(l)) >= 6]
        statements = [BULLET_RE.match(l).group(1) if BULLET_RE.match(l) else l for l in source]
        statements = [s for s in statements if len(_words(s)) >= 5]
    bullet_count = max(len(marker_lines), info.get("bullets", 0))

    # length (10)
    if 250 <= words <= 700:
        checks.append(_check("length", "Content", "Length", "pass", 10, 10, f"{words} words: a good length."))
    elif 150 <= words < 250 or 700 < words <= 900:
        tip = "Add more detail about projects and skills." if words < 250 else "Cut older or minor details to fit one or two pages."
        checks.append(_check("length", "Content", "Length", "warn", 5, 10, f"{words} words.", tip))
    else:
        tip = "A resume this short looks empty. Add projects, skills and education details." if words < 150 else "Too long. Keep it to the most relevant 1-2 pages."
        checks.append(_check("length", "Content", "Length", "fail", 0, 10, f"{words} words.", tip))

    # action verbs (10)
    def is_action(sentence):
        first = (_words(sentence) or [""])[0].lower()
        return first in ACTION_VERBS or (len(first) > 3 and first.endswith("ed"))
    if statements:
        good = sum(1 for s in statements if is_action(s))
        ratio = good / len(statements)
        if ratio >= 0.6 and len(statements) >= 4:
            checks.append(_check("verbs", "Content", "Action verbs", "pass", 10, 10,
                                 f"{good} of {len(statements)} statements start with an action verb."))
        elif ratio >= 0.3:
            checks.append(_check("verbs", "Content", "Action verbs", "warn", 5, 10,
                                 f"Only {good} of {len(statements)} statements start with an action verb.",
                                 "Start each point with a verb such as Built, Designed, Reduced, Improved."))
        else:
            checks.append(_check("verbs", "Content", "Action verbs", "fail", 0, 10,
                                 f"Only {good} of {len(statements)} statements start with an action verb.",
                                 "Rewrite points to start with a verb: Built, Designed, Reduced, Improved."))
    else:
        checks.append(_check("verbs", "Content", "Action verbs", "fail", 0, 10,
                             "No project or experience points were found.",
                             "Describe each project or job in 2-4 short points."))

    # bullets (5)
    if bullet_count >= 4:
        checks.append(_check("bullets", "Content", "Bullet points", "pass", 5, 5, f"{bullet_count} bullet points."))
    else:
        checks.append(_check("bullets", "Content", "Bullet points", "warn" if bullet_count else "fail",
                             2 if bullet_count else 0, 5,
                             f"{bullet_count} bullet points found.",
                             "Use short bullet points instead of long paragraphs."))

    # numbers (10)
    with_numbers = sum(1 for s in statements if re.search(r"\d", s))
    if with_numbers >= 2:
        checks.append(_check("numbers", "Content", "Numbers and results", "pass", 10, 10,
                             f"{with_numbers} points include numbers."))
    elif with_numbers == 1:
        checks.append(_check("numbers", "Content", "Numbers and results", "warn", 5, 10,
                             "Only 1 point includes a number.",
                             "Add numbers: users, accuracy, time saved, files processed, percent improved."))
    else:
        checks.append(_check("numbers", "Content", "Numbers and results", "fail", 0, 10,
                             "No point includes a number.",
                             "Add real numbers where you have them (accuracy, users, speed). Do not invent any."))

    # weak phrases (5)
    weak = [p for p in WEAK_PHRASES if p in low]
    if not weak:
        checks.append(_check("weak", "Content", "Cliches", "pass", 5, 5, "No common cliches found."))
    elif len(weak) <= 2:
        checks.append(_check("weak", "Content", "Cliches", "warn", 2, 5,
                             "Found: " + ", ".join(weak) + ".", "Replace these with a specific example."))
    else:
        checks.append(_check("weak", "Content", "Cliches", "fail", 0, 5,
                             "Found: " + ", ".join(weak) + ".", "Replace these with specific examples."))

    # first person (3)
    body = "\n".join(l for l in lines if not heading_key(l))
    pronouns = len(re.findall(r"\bI\b", body)) + len(re.findall(r"\b(?:my|me|myself)\b", body, re.I))
    if pronouns <= 2:
        checks.append(_check("pronouns", "Content", "First-person words", "pass", 3, 3, "Resume style is correct."))
    else:
        checks.append(_check("pronouns", "Content", "First-person words", "warn", 1, 3,
                             f"Found {pronouns} uses of I / my / me.",
                             "Resumes drop these. Write 'Built a web app' instead of 'I built my web app'."))

    # skills count (5)
    skills = find_skills(text)
    if len(skills) >= 8:
        checks.append(_check("skillcount", "Content", "Skills listed", "pass", 5, 5, f"{len(skills)} known skills found."))
    elif len(skills) >= 4:
        checks.append(_check("skillcount", "Content", "Skills listed", "warn", 3, 5, f"{len(skills)} known skills found.",
                             "List more of the tools you actually know."))
    else:
        checks.append(_check("skillcount", "Content", "Skills listed", "fail", 0, 5, f"{len(skills)} known skills found.",
                             "List your languages, frameworks, databases and tools."))

    # dates (5)
    named = bool(DATE_NAME_RE.search(text))
    numeric = bool(DATE_NUM_RE.search(text))
    years = len(re.findall(r"\b(?:19|20)\d{2}\b", text))
    if named and numeric:
        checks.append(_check("dates", "Content", "Dates", "warn", 3, 5, "Two date styles are mixed.",
                             "Use one style everywhere, for example 'Jun 2025'."))
    elif years >= 2:
        checks.append(_check("dates", "Content", "Dates", "pass", 5, 5, "Dates found and consistent."))
    else:
        checks.append(_check("dates", "Content", "Dates", "warn", 2, 5, "Few or no dates found.",
                             "Add start and end dates to education, internships and projects."))

    # ---- Format / ATS (12)
    ext = info.get("ext", "")
    if ext == ".photo" or info.get("scanned"):
        checks.append(_check("filetype", "Format", "File type", "warn", 1, 3,
                             "This is a photo or a scanned PDF, not a file with real text.",
                             "ATS cannot read pictures. Keep an editable version and export a PDF or DOCX from it."))
    elif ext in (".pdf", ".docx"):
        checks.append(_check("filetype", "Format", "File type", "pass", 3, 3, f"{ext[1:].upper()} is accepted by ATS."))
    elif ext == ".txt":
        checks.append(_check("filetype", "Format", "File type", "warn", 1, 3, "Plain text has no formatting.",
                             "Send a PDF or DOCX made from a clean template."))
    else:
        checks.append(_check("filetype", "Format", "File type", "pass", 3, 3, "File type not checked."))
    tables = info.get("tables", 0)
    if tables == 0:
        checks.append(_check("tables", "Format", "Tables and columns", "pass", 3, 3, "No tables found."))
    else:
        checks.append(_check("tables", "Format", "Tables and columns", "warn", 1, 3, f"{tables} table(s) found.",
                             "Many ATS read tables in the wrong order. Use plain headings and bullets."))
    images = info.get("images", 0)
    if images == 0:
        checks.append(_check("images", "Format", "Images and graphics", "pass", 3, 3, "No images found."))
    else:
        checks.append(_check("images", "Format", "Images and graphics", "warn", 1, 3, f"{images} image(s) found.",
                             "ATS cannot read photos, icons or skill bars. Put skills in plain text."))
    pages = info.get("pages")
    if pages is None:
        checks.append(_check("pages", "Format", "Page count", "pass", 3, 3, "Page count is unknown for this file type."))
    elif pages == 1:
        checks.append(_check("pages", "Format", "Page count", "pass", 3, 3, "1 page: ideal for freshers."))
    elif pages == 2:
        checks.append(_check("pages", "Format", "Page count", "warn", 2, 3, "2 pages.",
                             "Freshers should aim for 1 page. 2 is fine with several years of experience."))
    else:
        checks.append(_check("pages", "Format", "Page count", "fail", 0, 3, f"{pages} pages.",
                             "Cut it down to 1-2 pages."))

    score = sum(c["points"] for c in checks)
    label = "Excellent" if score >= 85 else "Good" if score >= 70 else "Needs work" if score >= 50 else "Weak"
    return {
        "score": score,
        "label": label,
        "checks": checks,
        "skills_found": skills,
        "sections_found": found_sections,
        "stats": {"words": words, "bullets": bullet_count, "pages": pages, "skills": len(skills)},
    }


def role_match(text: str, role_key: str = None, job_description: str = None, company: str = "") -> dict:
    """Which skills the target needs, which the resume shows, and which are missing."""
    have = set(find_skills(text))
    if job_description and job_description.strip():
        required = find_skills(job_description)
        nice = []
        label = (company + " job post") if company else "your job post"
        source = "job_description"
    elif role_key in ROLE_PROFILES:
        prof = ROLE_PROFILES[role_key]
        required, nice = prof["core"], prof["nice"]
        label = prof["label"] + " (typical skills)"
        source = "role"
    else:
        return {}
    matched = [s for s in required if s in have]
    missing = [s for s in required if s not in have]
    coverage = round(100 * len(matched) / len(required)) if required else None
    out = {
        "label": label,
        "source": source,
        "required": required,
        "matched": matched,
        "missing": missing,
        "nice_missing": [s for s in nice if s not in have],
        "coverage": coverage,
        "note": "",
    }
    if source == "job_description" and not required:
        out["note"] = "No known skills were found in that job post, so no skill match could be calculated."
    if source == "role":
        out["note"] = "Typical skills for this role. They are not any company's official requirements. Paste a company's job post for a real match."
    return out
