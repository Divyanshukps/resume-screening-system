"""Build a clean, ATS-friendly resume (DOCX download + HTML preview) from structured data.

The layout is one column with plain headings and bullets: no tables, no images, no icons,
because those are what applicant tracking systems read badly.
"""
import io
import re

from docx import Document
from docx.enum.text import WD_ALIGN_PARAGRAPH, WD_TAB_ALIGNMENT
from docx.oxml import OxmlElement
from docx.oxml.ns import qn
from docx.shared import Inches, Pt, RGBColor

from .profiles import ROLE_KEYWORDS, SKILLS, find_skills

EMAIL_RE = re.compile(r"[\w.+-]+@[\w-]+\.[\w.-]+")
PHONE_RE = re.compile(r"(?<!\d)(?:\+?91[\s-]?)?[6-9]\d{4}[\s-]?\d{5}(?!\d)")

EMPTY_RESUME = {
    "name": "", "title": "", "email": "", "phone": "", "location": "", "links": [], "summary": "",
    "skills": [], "education": [], "experience": [], "projects": [], "certifications": [],
}


def _s(v, n=200):
    return re.sub(r"\s+", " ", str(v or "")).strip()[:n]


def _list(v, n=12, ln=300):
    items = v if isinstance(v, list) else []
    return [x for x in (_s(i, ln) for i in items) if x][:n]


def clean_resume(d: dict) -> dict:
    """Trim, limit and normalise anything coming from the browser or from an AI."""
    d = d if isinstance(d, dict) else {}
    skills = []
    raw = d.get("skills") or []
    if raw and all(isinstance(x, str) for x in raw):
        raw = [{"label": "Skills", "items": raw}]
    for g in raw[:8] if isinstance(raw, list) else []:
        if isinstance(g, dict):
            items = _list(g.get("items"), 25, 40)
            if items:
                skills.append({"label": _s(g.get("label"), 40) or "Skills", "items": items})
    out = {
        "name": _s(d.get("name"), 80), "title": _s(d.get("title"), 80), "email": _s(d.get("email"), 80),
        "phone": _s(d.get("phone"), 30), "location": _s(d.get("location"), 60),
        "links": _list(d.get("links"), 4, 80), "summary": _s(d.get("summary"), 600), "skills": skills,
        "education": [], "experience": [], "projects": [], "certifications": _list(d.get("certifications"), 8, 120),
    }
    for e in (d.get("education") or [])[:4] if isinstance(d.get("education"), list) else []:
        if isinstance(e, dict):
            item = {"degree": _s(e.get("degree"), 120), "school": _s(e.get("school"), 120),
                    "dates": _s(e.get("dates"), 40), "detail": _s(e.get("detail"), 160)}
            if item["degree"] or item["school"]:
                out["education"].append(item)
    for e in (d.get("experience") or [])[:5] if isinstance(d.get("experience"), list) else []:
        if isinstance(e, dict):
            item = {"role": _s(e.get("role"), 100), "company": _s(e.get("company"), 100),
                    "dates": _s(e.get("dates"), 40), "bullets": _list(e.get("bullets"), 6, 260)}
            if item["role"] or item["company"]:
                out["experience"].append(item)
    for e in (d.get("projects") or [])[:5] if isinstance(d.get("projects"), list) else []:
        if isinstance(e, dict):
            item = {"name": _s(e.get("name"), 100), "tech": _s(e.get("tech"), 120),
                    "link": _s(e.get("link"), 100), "bullets": _list(e.get("bullets"), 5, 260)}
            if item["name"]:
                out["projects"].append(item)
    return out


def layout(r: dict, style: str = "fresher") -> list:
    """Ordered sections. Freshers lead with education and projects; experienced people with experience."""
    sections = []
    if r["summary"]:
        sections.append({"title": "Summary", "kind": "text", "items": r["summary"]})
    edu = {"title": "Education", "kind": "education", "items": r["education"]} if r["education"] else None
    skills = {"title": "Skills", "kind": "skills", "items": r["skills"]} if r["skills"] else None
    exp = {"title": "Experience", "kind": "experience", "items": r["experience"]} if r["experience"] else None
    proj = {"title": "Projects", "kind": "projects", "items": r["projects"]} if r["projects"] else None
    certs = {"title": "Certifications", "kind": "list", "items": r["certifications"]} if r["certifications"] else None
    order = [edu, skills, proj, exp, certs] if style == "fresher" else [skills, exp, proj, edu, certs]
    return sections + [s for s in order if s]


def contact_line(r: dict) -> list:
    return [x for x in [r["email"], r["phone"], r["location"], *r["links"]] if x]


# ---------------------------------------------------------------- DOCX
def _rule(paragraph):
    pPr = paragraph._p.get_or_add_pPr()
    borders = OxmlElement("w:pBdr")
    bottom = OxmlElement("w:bottom")
    for k, v in (("w:val", "single"), ("w:sz", "6"), ("w:space", "1"), ("w:color", "808080")):
        bottom.set(qn(k), v)
    borders.append(bottom)
    pPr.append(borders)


def _para(doc, text="", bold=False, size=10.5, align=None, before=0, after=0, italic=False):
    p = doc.add_paragraph()
    pf = p.paragraph_format
    pf.space_before, pf.space_after = Pt(before), Pt(after)
    if align:
        p.alignment = align
    if text:
        run = p.add_run(text)
        run.bold, run.italic, run.font.size = bold, italic, Pt(size)
    return p


def _entry(doc, left, right, sub=""):
    p = _para(doc, before=4)
    p.paragraph_format.tab_stops.add_tab_stop(Inches(7.1), WD_TAB_ALIGNMENT.RIGHT)
    run = p.add_run(left)
    run.bold, run.font.size = True, Pt(10.5)
    if right:
        r2 = p.add_run("\t" + right)
        r2.font.size = Pt(10)
    if sub:
        s = _para(doc, sub, size=10, italic=True)
        return s
    return p


def _bullets(doc, items):
    for b in items:
        p = doc.add_paragraph(style="List Bullet")
        p.paragraph_format.space_after = Pt(1)
        p.paragraph_format.space_before = Pt(0)
        run = p.add_run(b)
        run.font.size = Pt(10.5)


def build_docx(r: dict, style: str = "fresher") -> bytes:
    doc = Document()
    sec = doc.sections[0]
    sec.left_margin = sec.right_margin = Inches(0.7)
    sec.top_margin = sec.bottom_margin = Inches(0.6)
    normal = doc.styles["Normal"]
    normal.font.name = "Calibri"
    normal.element.rPr.rFonts.set(qn("w:eastAsia"), "Calibri")
    normal.font.size = Pt(10.5)
    normal.font.color.rgb = RGBColor(0x1A, 0x1A, 0x1A)

    _para(doc, r["name"] or "Your Name", bold=True, size=20, align=WD_ALIGN_PARAGRAPH.CENTER)
    if r["title"]:
        _para(doc, r["title"], size=11, align=WD_ALIGN_PARAGRAPH.CENTER)
    contact = contact_line(r)
    if contact:
        _para(doc, "  |  ".join(contact), size=10, align=WD_ALIGN_PARAGRAPH.CENTER, after=2)

    for s in layout(r, style):
        h = _para(doc, s["title"].upper(), bold=True, size=11, before=8, after=2)
        _rule(h)
        k, items = s["kind"], s["items"]
        if k == "text":
            _para(doc, items)
        elif k == "skills":
            for g in items:
                p = _para(doc)
                a = p.add_run(g["label"] + ": ")
                a.bold = True
                p.add_run(", ".join(g["items"]))
        elif k == "education":
            for e in items:
                _entry(doc, e["degree"] or e["school"], e["dates"], e["school"] if e["degree"] else "")
                if e["detail"]:
                    _para(doc, e["detail"], size=10)
        elif k == "experience":
            for e in items:
                _entry(doc, e["role"] or e["company"], e["dates"], e["company"] if e["role"] else "")
                _bullets(doc, e["bullets"])
        elif k == "projects":
            for e in items:
                _entry(doc, e["name"], e["link"], ("Tech: " + e["tech"]) if e["tech"] else "")
                _bullets(doc, e["bullets"])
        elif k == "list":
            _bullets(doc, items)
    buf = io.BytesIO()
    doc.save(buf)
    return buf.getvalue()


# ---------------------------------------------------------------- basic draft (no AI)
def draft_from_prompt(prompt: str) -> dict:
    """Fill what can be found in a plain description. Everything else becomes a [placeholder]."""
    text = prompt or ""
    low = text.lower()
    found_email = EMAIL_RE.search(text)
    email = found_email.group(0) if found_email else ""
    phone = PHONE_RE.search(text)
    name = ""
    m = re.search(r"(?i:my name is|i am|i'm|name\s*[:=-])\s+([A-Z][a-zA-Z]+(?:\s+[A-Z][a-zA-Z]+){0,3})", text)
    if m:
        name = m.group(1)
    title = ""
    for kw, key in ROLE_KEYWORDS.items():
        if kw in low:
            title = kw.title()
            break
    skills = [s for s in find_skills(text)]
    pretty = {"sql": "SQL", "html": "HTML", "css": "CSS", "nlp": "NLP", "oop": "OOP", "aws": "AWS", "git": "Git",
              "mysql": "MySQL", "postgresql": "PostgreSQL", "mongodb": "MongoDB", "numpy": "NumPy",
              "github": "GitHub", "javascript": "JavaScript", "typescript": "TypeScript", "fastapi": "FastAPI",
              "rest api": "REST API", "node.js": "Node.js", "scikit-learn": "scikit-learn", "power bi": "Power BI",
              "tensorflow": "TensorFlow", "pytorch": "PyTorch", "opencv": "OpenCV", "junit": "JUnit",
              "pytest": "pytest", "c++": "C++", "sqlite": "SQLite", "dsa": "DSA"}
    skills = [pretty.get(s, s.title()) for s in skills if s not in ("communication", "problem solving")]
    degree = ""
    d = re.search(r"\b(b\.?\s?tech|b\.?\s?e\.?|bca|mca|m\.?\s?tech|b\.?\s?sc|m\.?\s?sc|mba)\b[^\n]{0,90}", text, re.I)
    if d:
        degree = re.split(r"\s+(?:at|from|graduating|passing|expected|batch)\b|[,.](?:\s|$)|\.\s", d.group(0), maxsplit=1)[0]
        degree = re.sub(r"\s+student\b", "", degree, flags=re.I).strip(" -:")
    year = re.search(r"\b(?:graduating|passing out|expected|batch(?: of)?|class of)\D{0,12}((?:20)\d\d)", text, re.I)
    dates = f"Expected {year.group(1)}" if year else "[Start year - End year]"

    projects = []
    for m in re.finditer(r"\bprojects?\s*[:\-]\s*(.+?)(?=\s+projects?\s*[:\-]|\s+(?:i\s+did|i\s+worked|internship|i\s+want)\b|$)", text, re.I | re.S):
        sentence = re.sub(r"\s+", " ", m.group(1)).strip().rstrip(".")
        if len(sentence) < 8:
            continue
        name = " ".join(re.split(r"\s+(?:in|using|for|with|that|which)\s+|,", sentence, maxsplit=1)[0].split()[:5])
        projects.append({"name": name[:1].upper() + name[1:], "tech": ", ".join(find_skills(sentence)[:4]).title() if False else "",
                         "link": "", "bullets": [sentence[:250] + ".", "[Rewrite as short points that start with a verb. Add one real number.]"]})
        if len(projects) == 3:
            break
    experience = []
    it = re.search(r"\b(?:(\d+)\s*[- ]?month\s+)?([A-Za-z+#]{2,15}\s+)?internship\b(?:\s+(?:in|during)\s+((?:20)\d\d))?", text, re.I)
    if it:
        kind = (it.group(2) or "").strip()
        experience.append({"role": (kind.title() + " Intern").strip(), "company": "[Company name]",
                           "dates": it.group(3) or "[Dates]", "bullets": ["[What you did. Add one real number.]"]})
    data = dict(EMPTY_RESUME)
    data.update({
        "name": name or "[Your name]", "title": title, "email": email or "[your-email@example.com]",
        "phone": phone.group(0) if phone else "[Phone number]", "location": "[City, State]",
        "links": ["github.com/[your-username]"],
        "summary": (f"{title or 'Aspiring professional'} with hands-on project experience in "
                    f"{', '.join(skills[:4]) or '[your main skills]'}. [Add one line about what you want to work on.]"),
        "skills": [{"label": "Skills", "items": skills or ["[Add your skills]"]}],
        "education": [{"degree": degree or "[Your degree]", "school": "[Your college]", "dates": dates, "detail": ""}],
        "projects": projects or [{"name": "[Project name]", "tech": ", ".join(skills[:4]), "link": "",
                                  "bullets": ["[Built / Designed / Improved ...] [what it does] using [tools].",
                                              "[Add one real number: users, accuracy, time saved]."]}],
        "experience": experience,
        "certifications": [],
    })
    return clean_resume(data)
