"""Optional AI helpers (resume drafting and plain-language rewriting).

They run only when the server has an ANTHROPIC_API_KEY environment variable. Without it the
rest of the website works normally and these features show a clear "not connected" message.
Text is sent to the AI service only when a person clicks an AI button.
"""
import json
import os
import re
import threading
import time
import urllib.error
import urllib.request
from collections import defaultdict, deque

API_URL = "https://api.anthropic.com/v1/messages"
DEFAULT_MODEL = "claude-sonnet-5-5"


class AIUnavailable(Exception):
    pass


class AIError(Exception):
    pass


class RateLimited(Exception):
    pass


def ai_enabled() -> bool:
    return bool(os.environ.get("ANTHROPIC_API_KEY", "").strip())


_lock = threading.Lock()
_by_client = defaultdict(deque)
_all_calls = deque()


def check_limit(client: str) -> None:
    """Protects the owner's API bill: a per-person hourly limit and a site-wide daily limit."""
    per_hour = int(os.environ.get("AI_LIMIT_PER_HOUR", "8"))
    per_day = int(os.environ.get("AI_LIMIT_PER_DAY", "300"))
    now = time.time()
    with _lock:
        mine = _by_client[client]
        while mine and now - mine[0] > 3600:
            mine.popleft()
        while _all_calls and now - _all_calls[0] > 86400:
            _all_calls.popleft()
        if len(_by_client) > 5000:
            _by_client.clear()
        if len(mine) >= per_hour:
            raise RateLimited("You have reached the hourly limit for AI help. Please try again later.")
        if len(_all_calls) >= per_day:
            raise RateLimited("AI help has reached its daily limit on this site. Please try again tomorrow.")
        mine.append(now)
        _all_calls.append(now)


def _call(system: str, user: str, max_tokens: int = 2500) -> str:
    key = os.environ.get("ANTHROPIC_API_KEY", "").strip()
    if not key:
        raise AIUnavailable("AI help is not connected on this server.")
    body = json.dumps({
        "model": os.environ.get("AI_MODEL", DEFAULT_MODEL),
        "max_tokens": max_tokens,
        "system": system,
        "messages": [{"role": "user", "content": user}],
    }).encode()
    req = urllib.request.Request(API_URL, data=body, headers={
        "content-type": "application/json", "x-api-key": key, "anthropic-version": "2023-06-01"})
    try:
        with urllib.request.urlopen(req, timeout=60) as resp:
            data = json.load(resp)
    except urllib.error.HTTPError as exc:
        raise AIError(f"The AI service returned an error ({exc.code}).")
    except Exception:
        raise AIError("Could not reach the AI service. Try again in a moment.")
    return "".join(b.get("text", "") for b in data.get("content", []) if b.get("type") == "text")


SCHEMA = """{
  "name": "", "title": "", "email": "", "phone": "", "location": "", "links": [""],
  "summary": "2 short sentences",
  "skills": [{"label": "Languages", "items": [""]}],
  "education": [{"degree": "", "school": "", "dates": "", "detail": ""}],
  "experience": [{"role": "", "company": "", "dates": "", "bullets": [""]}],
  "projects": [{"name": "", "tech": "", "link": "", "bullets": [""]}],
  "certifications": [""]
}"""

RESUME_SYSTEM = f"""You turn a person's description into resume content. Return ONLY one JSON object in exactly this shape, with no other text:
{SCHEMA}

Rules:
- Use ONLY facts the person gave. Never invent employers, degrees, dates, links, scores or numbers.
- Where a needed fact is missing, write a placeholder in square brackets, such as [add number] or [your college].
- Write plain, natural English the way a careful student would. Short bullets that start with a verb. No buzzwords (no 'results-driven', 'passionate', 'leveraged', 'spearheaded', 'cutting-edge'), no long dashes.
- Each project or job gets 2 to 4 bullets. Leave a list empty if the person gave nothing for it."""

IMPROVE_SYSTEM = """Rewrite the resume text in plain, natural language the way a careful person writes.
Keep every fact exactly. Do not add new facts, tools, employers or numbers. Remove buzzwords and filler.
Keep the same line structure. Return only the rewritten text."""


def _parse_json(text: str) -> dict:
    start, end = text.find("{"), text.rfind("}")
    if start == -1 or end <= start:
        raise AIError("The AI reply could not be read. Please try again.")
    try:
        return json.loads(text[start:end + 1])
    except json.JSONDecodeError:
        raise AIError("The AI reply could not be read. Please try again.")


def generate_resume(prompt: str, style: str) -> dict:
    user = f"Layout style: {style}.\n\nPerson's description:\n{prompt[:4000]}"
    return _parse_json(_call(RESUME_SYSTEM, user))


def improve_text(text: str) -> str:
    out = _call(IMPROVE_SYSTEM, text[:6000], max_tokens=2500)
    return re.sub(r"^```[a-z]*\n|\n```$", "", out.strip())
