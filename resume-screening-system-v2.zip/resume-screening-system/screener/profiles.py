"""Skill vocabulary and role presets.

ROLE_PROFILES are TYPICAL skills for a role. They are not official requirements of any
company. For a specific company, paste that company's job post into the checker instead.
"""
import re

# canonical skill -> spellings people use for it
SKILLS = {
    "python": ["python"],
    "java": ["java"],
    "c++": ["c++"],
    "javascript": ["javascript", "js"],
    "typescript": ["typescript"],
    "sql": ["sql"],
    "mysql": ["mysql"],
    "postgresql": ["postgresql", "postgres"],
    "mongodb": ["mongodb", "mongo db"],
    "sqlite": ["sqlite"],
    "html": ["html", "html5"],
    "css": ["css", "css3"],
    "react": ["react", "reactjs", "react.js"],
    "node.js": ["node.js", "nodejs", "node js"],
    "flask": ["flask"],
    "django": ["django"],
    "fastapi": ["fastapi"],
    "spring boot": ["spring boot", "springboot"],
    "hibernate": ["hibernate", "jpa"],
    "maven": ["maven"],
    "rest api": ["rest api", "rest apis", "restful", "restful api", "restful apis"],
    "git": ["git"],
    "github": ["github"],
    "docker": ["docker"],
    "linux": ["linux"],
    "aws": ["aws", "amazon web services"],
    "pandas": ["pandas"],
    "numpy": ["numpy"],
    "matplotlib": ["matplotlib"],
    "scikit-learn": ["scikit-learn", "scikit learn", "sklearn"],
    "tensorflow": ["tensorflow"],
    "keras": ["keras"],
    "pytorch": ["pytorch"],
    "opencv": ["opencv"],
    "nlp": ["nlp", "natural language processing"],
    "machine learning": ["machine learning", "ml"],
    "deep learning": ["deep learning"],
    "data visualization": ["data visualization", "data visualisation", "dashboard", "dashboards", "power bi", "tableau", "matplotlib", "seaborn", "plotly", "looker"],
    "statistics": ["statistics", "statistical analysis"],
    "excel": ["excel", "ms excel", "microsoft excel"],
    "power bi": ["power bi", "powerbi"],
    "tableau": ["tableau"],
    "oop": ["oop", "oops", "object oriented programming", "object-oriented programming"],
    "data structures": ["data structures", "dsa"],
    "algorithms": ["algorithms"],
    "junit": ["junit"],
    "pytest": ["pytest"],
    "jenkins": ["jenkins"],
    "figma": ["figma"],
    "communication": ["communication", "communication skills"],
    "problem solving": ["problem solving", "problem-solving"],
}

ROLE_PROFILES = {
    "data-analyst": {
        "label": "Data Analyst",
        "core": ["python", "sql", "excel", "pandas", "data visualization", "statistics"],
        "nice": ["numpy", "power bi", "tableau", "matplotlib", "machine learning", "git", "communication"],
    },
    "python-developer": {
        "label": "Python Developer",
        "core": ["python", "git", "rest api", "sql", "oop"],
        "nice": ["flask", "django", "fastapi", "docker", "pytest", "linux", "postgresql"],
    },
    "java-developer": {
        "label": "Java Developer",
        "core": ["java", "oop", "sql", "data structures", "git", "rest api"],
        "nice": ["spring boot", "mysql", "junit", "docker", "maven", "hibernate"],
    },
    "ml-ai-engineer": {
        "label": "ML / AI Engineer",
        "core": ["python", "machine learning", "numpy", "pandas", "scikit-learn", "deep learning"],
        "nice": ["tensorflow", "keras", "pytorch", "nlp", "opencv", "git", "docker", "sql"],
    },
    "web-developer": {
        "label": "Web Developer",
        "core": ["html", "css", "javascript", "react", "git", "rest api"],
        "nice": ["node.js", "typescript", "mongodb", "figma", "sql"],
    },
    "software-engineer-fresher": {
        "label": "Software Engineer (Fresher)",
        "core": ["data structures", "algorithms", "oop", "git", "sql", "problem solving"],
        "nice": ["python", "java", "c++", "linux", "docker"],
    },
}

ROLE_LIST = [{"key": k, "label": v["label"]} for k, v in ROLE_PROFILES.items()]

# words in a free-text prompt that point to a role (used when AI is off)
ROLE_KEYWORDS = {
    "data analyst": "data-analyst",
    "data analysis": "data-analyst",
    "python developer": "python-developer",
    "backend": "python-developer",
    "java developer": "java-developer",
    "java": "java-developer",
    "machine learning": "ml-ai-engineer",
    "ml engineer": "ml-ai-engineer",
    "ai engineer": "ml-ai-engineer",
    "web developer": "web-developer",
    "frontend": "web-developer",
    "front end": "web-developer",
    "software engineer": "software-engineer-fresher",
    "software developer": "software-engineer-fresher",
}


def _pattern(alias: str):
    return re.compile(r"(?<![a-z0-9+#.])" + re.escape(alias) + r"(?![a-z0-9+#])")


_PATTERNS = {canon: [_pattern(a) for a in aliases] for canon, aliases in SKILLS.items()}


def find_skills(text: str) -> list:
    """Canonical skill names that appear in the text (in vocabulary order)."""
    low = (text or "").lower()
    return [canon for canon, pats in _PATTERNS.items() if any(p.search(low) for p in pats)]
