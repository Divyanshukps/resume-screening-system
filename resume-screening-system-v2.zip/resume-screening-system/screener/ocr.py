"""Read text from a photo or a scanned PDF using Tesseract OCR, and judge the photo quality.

Needs the Tesseract program installed on the machine (apt install tesseract-ocr).
Nothing is saved: images are processed in memory and a temporary file that is deleted at once.
"""
import io
import os
import shutil
import subprocess
import tempfile

import numpy as np
from PIL import Image, ImageOps

Image.MAX_IMAGE_PIXELS = 40_000_000  # refuse absurdly large images
PSM = os.environ.get("OCR_PSM", "4")


class OcrUnavailable(Exception):
    """Tesseract is not installed on this machine."""


def tesseract_available() -> bool:
    return shutil.which("tesseract") is not None


def image_quality(img: Image.Image) -> dict:
    """Simple checks that explain most bad OCR: small, dark or blurry photos."""
    w, h = img.size
    gray = ImageOps.exif_transpose(img).convert("L")
    gray.thumbnail((900, 900))
    arr = np.asarray(gray, dtype=float)
    brightness = float(arr.mean())
    lap = 4 * arr[1:-1, 1:-1] - arr[:-2, 1:-1] - arr[2:, 1:-1] - arr[1:-1, :-2] - arr[1:-1, 2:]
    sharpness = float(lap.var())
    warnings = []
    if w < 1000:
        warnings.append("The photo is small. Use the phone's normal camera resolution, not a thumbnail or a forwarded copy.")
    if brightness < 95:
        warnings.append("The photo is dark. Take it in daylight or under a bright lamp.")
    if sharpness < 25:
        warnings.append("The photo looks blurry. Hold the phone steady, tap the screen to focus, and retake it.")
    return {"width": w, "height": h, "brightness": round(brightness), "sharpness": round(sharpness), "warnings": warnings}


def prepare(img: Image.Image) -> Image.Image:
    img = ImageOps.exif_transpose(img).convert("L")
    w, h = img.size
    if w < 1600:
        img = img.resize((1600, max(1, int(h * 1600 / w))), Image.LANCZOS)
    elif w > 3200:
        img = img.resize((3200, max(1, int(h * 3200 / w))), Image.LANCZOS)
    return ImageOps.autocontrast(img, cutoff=1)


def parse_tsv(tsv: str) -> dict:
    """Turn Tesseract's TSV output into lines of text and an average confidence."""
    lines, confs = {}, []
    for row in tsv.splitlines()[1:]:
        parts = row.split("\t")
        if len(parts) < 12:
            continue
        try:
            conf = float(parts[10])
        except ValueError:
            continue
        word = parts[11].strip()
        if conf < 0 or not word:
            continue
        key = (int(parts[2]), int(parts[3]), int(parts[4]))  # block, paragraph, line
        lines.setdefault(key, []).append(word)
        confs.append(conf)
    text = "\n".join(" ".join(ws) for _, ws in sorted(lines.items()))
    return {"text": text, "confidence": round(sum(confs) / len(confs)) if confs else 0, "words": len(confs)}


def ocr_image(img: Image.Image) -> dict:
    if not tesseract_available():
        raise OcrUnavailable("Photo reading is not set up on this server (Tesseract is missing).")
    prepared = prepare(img)
    with tempfile.TemporaryDirectory() as tmp:
        path = os.path.join(tmp, "page.png")
        prepared.save(path)
        env = dict(os.environ, OMP_THREAD_LIMIT="1")
        proc = subprocess.run(
            ["tesseract", path, "stdout", "-l", "eng", "--psm", PSM, "tsv"],
            capture_output=True, text=True, timeout=90, env=env,
        )
    if proc.returncode != 0:
        raise RuntimeError("The text reader failed on this image.")
    return parse_tsv(proc.stdout)


def open_image(data: bytes) -> Image.Image:
    try:
        img = Image.open(io.BytesIO(data))
        img.load()
        return img
    except Exception:
        raise ValueError("This image could not be opened. Use a JPG or PNG (iPhone HEIC photos must be converted or screenshotted first).")


def ocr_bytes(data: bytes) -> dict:
    """OCR for an uploaded photo. Returns text, confidence and plain-language warnings."""
    img = open_image(data)
    quality = image_quality(img)
    out = ocr_image(img)
    warnings = list(quality["warnings"])
    if out["words"] and out["confidence"] < 70:
        warnings.append(f"The text was hard to read (confidence {out['confidence']}%). Some words below may be misread.")
    out.update(quality=quality, warnings=warnings)
    return out


def ocr_pdf(data: bytes, max_pages: int = 2) -> dict:
    """OCR for a scanned PDF (pages that are pictures, with no real text)."""
    import pdfplumber

    texts, confs, words = [], [], 0
    with pdfplumber.open(io.BytesIO(data)) as pdf:
        for page in pdf.pages[:max_pages]:
            img = page.to_image(resolution=200).original
            res = ocr_image(img)
            texts.append(res["text"])
            confs.append(res["confidence"] * res["words"])
            words += res["words"]
    conf = round(sum(confs) / words) if words else 0
    warnings = []
    if words and conf < 70:
        warnings.append(f"The scan was hard to read (confidence {conf}%). Some words below may be misread.")
    return {"text": "\n".join(texts), "confidence": conf, "words": words, "warnings": warnings, "quality": None}
