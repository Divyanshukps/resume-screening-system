"""Read text out of PDF, DOCX, plain-text resumes, and photos or scans (via OCR)."""
import io
import re
from pathlib import Path

from .fileinfo import file_info
from .ocr import OcrUnavailable, ocr_bytes, ocr_pdf

IMAGE_EXTENSIONS = {".png", ".jpg", ".jpeg", ".webp"}
ALLOWED_EXTENSIONS = {".pdf", ".docx", ".txt"} | IMAGE_EXTENSIONS


def _read_pdf(data: bytes) -> str:
    try:
        import pdfplumber

        with pdfplumber.open(io.BytesIO(data)) as pdf:
            text = "\n".join((page.extract_text() or "") for page in pdf.pages)
        if text.strip():
            return text
    except Exception:
        pass
    from pypdf import PdfReader  # fallback parser

    reader = PdfReader(io.BytesIO(data))
    return "\n".join((page.extract_text() or "") for page in reader.pages)


def _read_docx(data: bytes) -> str:
    from docx import Document

    doc = Document(io.BytesIO(data))
    parts = [p.text for p in doc.paragraphs]
    for table in doc.tables:
        for row in table.rows:
            parts.extend(cell.text for cell in row.cells)
    return "\n".join(parts)


def _read_txt(data: bytes) -> str:
    for enc in ("utf-8", "latin-1"):
        try:
            return data.decode(enc)
        except UnicodeDecodeError:
            continue
    return ""


def read_resume(filename: str, data: bytes) -> dict:
    """
    Returns {text, info, source, scan}.
      source: 'text' (normal file), 'photo' (picture read by OCR), 'scan' (PDF made of pictures)
      scan:   OCR confidence and warnings, or None for normal files
    Raises OcrUnavailable when a photo is uploaded but Tesseract is not installed.
    """
    ext = Path(filename).suffix.lower()
    if ext not in ALLOWED_EXTENSIONS:
        raise ValueError(f"Unsupported file type: {ext or 'unknown'}")
    info = file_info(filename, data)
    out = {"text": "", "info": info, "source": "text", "scan": None}

    if ext in IMAGE_EXTENSIONS:
        ocr = ocr_bytes(data)
        info.update(ext=".photo", pages=1)
        out.update(text=ocr["text"], source="photo", scan=ocr)
    elif ext == ".pdf":
        text = _read_pdf(data)
        out["text"] = text
        if len(text.split()) < 40:  # almost no real text: probably a scanned PDF
            try:
                ocr = ocr_pdf(data)
            except OcrUnavailable:
                ocr = None
            if ocr and len(ocr["text"].split()) > len(text.split()):
                info["scanned"] = True
                out.update(text=ocr["text"], source="scan", scan=ocr)
    elif ext == ".docx":
        out["text"] = _read_docx(data)
    else:
        out["text"] = _read_txt(data)
    return out


def extract_text(filename: str, data: bytes) -> str:
    """Text of a resume, based on its file extension."""
    return read_resume(filename, data)["text"]


def guess_candidate_name(text: str, filename: str) -> str:
    """Use the first short, letters-only line as the name; else the file name."""
    for line in text.splitlines()[:6]:
        line = line.strip()
        if 2 <= len(line.split()) <= 4 and re.fullmatch(r"[A-Za-z .'\-]+", line):
            return line.title()
    return Path(filename).stem.replace("_", " ").replace("-", " ").title()
