let chosen = null;
let lastText = "";

function setFile(f) {
  if (!f) return;
  chosen = f;
  $("dropTitle").textContent = f.name;
  $("dropHint").textContent = "Click to choose a different file";
  $("error").hidden = true;
}

$("file").addEventListener("change", (e) => setFile(e.target.files[0]));
$("photo").addEventListener("change", (e) => setFile(e.target.files[0]));
["dragover", "dragenter"].forEach((ev) => $("drop").addEventListener(ev, (e) => { e.preventDefault(); $("drop").classList.add("over"); }));
["dragleave", "drop"].forEach((ev) => $("drop").addEventListener(ev, () => $("drop").classList.remove("over")));
$("drop").addEventListener("drop", (e) => { e.preventDefault(); setFile(e.dataTransfer.files[0]); });

getMeta().then((m) => {
  $("role").insertAdjacentHTML("beforeend", m.roles.map((r) => `<option value="${esc(r.key)}">${esc(r.label)}</option>`).join(""));
  if (!m.photo_reading) $("photoNote").hidden = false;
});

$("form").addEventListener("submit", async (e) => {
  e.preventDefault();
  const err = $("error");
  err.hidden = true;
  if (!chosen) { err.textContent = "Choose a resume file first."; err.hidden = false; return; }
  const form = new FormData();
  form.append("resume", chosen);
  form.append("role", $("role").value);
  form.append("company", $("company").value);
  form.append("job_description", $("jd").value);

  const btn = $("go");
  btn.disabled = true;
  btn.textContent = /\.(png|jpe?g|webp)$/i.test(chosen.name) ? "Reading the photo..." : "Checking...";
  try {
    const data = await api("/api/check", { method: "POST", body: form });
    render(data);
    $("out").scrollIntoView({ behavior: "smooth", block: "start" });
  } catch (ex) {
    err.textContent = ex.message;
    err.hidden = false;
  } finally {
    btn.disabled = false;
    btn.textContent = "Check resume";
  }
});

function ring(score) {
  const C = 2 * Math.PI * 52;
  return `<div class="ring">
    <svg width="124" height="124" viewBox="0 0 124 124" aria-hidden="true">
      <circle class="track" cx="62" cy="62" r="52" fill="none" stroke-width="12"></circle>
      <circle class="arc" cx="62" cy="62" r="52" fill="none" stroke-width="12" stroke-linecap="round"
        stroke="${scoreColor(score)}" stroke-dasharray="${C}" stroke-dashoffset="${C}" data-target="${C * (1 - score / 100)}"></circle>
    </svg>
    <div class="num"><div>${score}<small>out of 100</small></div></div>
  </div>`;
}

function issueHTML(c) {
  const mark = c.status === "fail" ? "x" : "!";
  return `<div class="issue">
    <span class="mk ${esc(c.status)}" aria-label="${c.status === "fail" ? "Needs fixing" : "Could be better"}">${mark}</span>
    <div><div class="t">${esc(c.title)}</div><div class="d">${esc(c.detail)}</div>
    ${c.tip ? `<div class="fix">${esc(c.tip)}</div>` : ""}</div></div>`;
}

function render(d) {
  lastText = d.extracted_text || "";
  const r = d.report, w = d.writing, m = d.match || {};
  const todo = r.checks.filter((c) => c.status !== "pass").sort((a, b) => (b.max - b.points) - (a.max - a.points));
  const done = r.checks.filter((c) => c.status === "pass");
  const company = $("company").value.trim();
  let html = `<div class="sheet">
    <div class="scorehead">${ring(r.score)}
      <div><h2>${esc(r.label)}${company ? ` for ${esc(company)}` : ""}</h2>
        <div class="stats">
          <span><b>${r.stats.words}</b> words</span>
          <span><b>${r.stats.bullets}</b> bullet points</span>
          ${r.stats.pages ? `<span><b>${r.stats.pages}</b> page${r.stats.pages > 1 ? "s" : ""}</span>` : ""}
          <span><b>${r.stats.skills}</b> skills found</span>
        </div>
        <p class="muted small" style="margin-top:6px">File: ${esc(d.file)}</p>
      </div>
    </div>`;

  if (d.scan) {
    html += `<div class="callout ${d.scan.warnings.length ? "bad" : ""}"><b>This file was read from a ${d.source === "photo" ? "photo" : "scan"}.</b>
      Text recognition was ${d.scan.confidence}% confident.
      ${d.scan.warnings.map((x) => `<div>${esc(x)}</div>`).join("")}
      <div>Some items below may be misread letters, not real mistakes. Open "What we read" at the bottom to compare.</div></div>`;
  }

  html += `<div class="section"><h3>${todo.length ? `Fix these first (${todo.length})` : "Nothing to fix"}</h3>
    ${todo.map(issueHTML).join("")}</div>`;
  if (done.length) {
    html += `<details class="passed"><summary>What is already good (${done.length})</summary><ul>${done.map((c) => `<li>${esc(c.title)}: ${esc(c.detail)}</li>`).join("")}</ul></details>`;
  }
  html += `</div>`;

  if (m.label) {
    html += `<div class="sheet section"><h2>Skills for ${esc(m.label)}</h2>`;
    if (m.coverage !== null && m.coverage !== undefined) {
      html += `<p>Your resume shows <b>${m.matched.length} of ${m.required.length}</b> skills this target asks for.</p>
        <div class="bar" role="img" aria-label="${m.coverage}% skill match"><i style="width:${m.coverage}%"></i></div>`;
    }
    html += m.matched.length ? `<p class="lbl">You show</p>${chips(m.matched, "have")}` : "";
    html += m.missing.length ? `<p class="lbl" style="margin-top:10px">Not on your resume</p>${chips(m.missing, "need")}` : "";
    html += m.nice_missing && m.nice_missing.length ? `<p class="lbl" style="margin-top:10px">Nice to have</p>${chips(m.nice_missing, "plain")}` : "";
    html += m.note ? `<p class="hint" style="margin-top:10px">${esc(m.note)}</p>` : "";
    html += `<p class="hint">Only add a skill to your resume if you really have it.</p></div>`;
  } else if (r.skills_found.length) {
    html += `<div class="sheet section"><h2>Skills found</h2>${chips(r.skills_found, "have")}
      <p class="hint">Pick a job or paste a job post on the left to see which skills are missing.</p></div>`;
  }

  html += `<div class="sheet section"><h2>Writing check: ${esc(w.label)}</h2>`;
  html += w.signals.length
    ? w.signals.map((s) => `<div class="issue"><span class="mk ${s.level === "warn" ? "warn" : "pass"}" style="${s.level === "warn" ? "" : "background:#7b8497"}">${s.level === "warn" ? "!" : "i"}</span>
        <div><div class="t">${esc(s.title)}</div><div class="d">${esc(s.detail)}</div><div class="fix">${esc(s.tip)}</div></div></div>`).join("")
    : `<p>No buzzword or pattern problems found.</p>`;
  if (w.phrases.length) {
    html += `<p class="lbl" style="margin-top:12px">Words to replace</p>` +
      w.phrases.map((p) => `<span class="chip plain">${esc(p.phrase)}${p.plain ? " &rarr; " + esc(p.plain) : " (cut it)"}</span>`).join("");
  }
  if (w.rewrites.length) {
    html += `<p class="lbl" style="margin-top:12px">Simpler versions of your lines</p>` +
      w.rewrites.map((x) => `<div class="rewrite"><span class="was">${esc(x.original)}</span><span class="now">${esc(x.suggested)}</span></div>`).join("");
  }
  html += `<p class="hint" style="margin-top:12px">${esc(w.note)}</p>
    <div id="aiBox" style="margin-top:12px"></div></div>`;

  html += `<details class="readout sheet section"><summary>What we read from your file</summary>
    <p class="hint">This is the text a recruiter's system would see. If words are missing or jumbled here, an ATS will struggle too.</p>
    <pre class="read">${esc(lastText)}</pre></details>`;

  $("out").innerHTML = html;
  const arc = document.querySelector(".ring .arc");
  if (arc) requestAnimationFrame(() => requestAnimationFrame(() => arc.setAttribute("stroke-dashoffset", arc.dataset.target)));
  setupAI();
}

async function setupAI() {
  const box = $("aiBox");
  if (!box) return;
  const m = await getMeta();
  if (!m.ai) {
    box.innerHTML = `<p class="hint">Rewriting with AI is not connected on this server.</p>`;
    return;
  }
  box.innerHTML = `<button class="btn ghost sm" id="aiBtn" type="button">Rewrite in plain language with AI</button>
    <p class="hint">Sends your resume text to the AI service. Check every line before you use it.</p><div id="aiOut"></div>`;
  $("aiBtn").addEventListener("click", async () => {
    const b = $("aiBtn");
    b.disabled = true;
    b.textContent = "Rewriting...";
    try {
      const res = await api("/api/ai/improve", { method: "POST", headers: { "Content-Type": "application/json" }, body: JSON.stringify({ text: lastText }) });
      $("aiOut").innerHTML = `<p class="lbl" style="margin-top:10px">AI rewrite</p><pre class="read">${esc(res.text)}</pre>`;
    } catch (ex) {
      $("aiOut").innerHTML = `<p class="error">${esc(ex.message)}</p>`;
    } finally {
      b.disabled = false;
      b.textContent = "Rewrite in plain language with AI";
    }
  });
}
