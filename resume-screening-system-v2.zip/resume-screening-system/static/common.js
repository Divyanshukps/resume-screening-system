/* Shared helpers. Every piece of text that came from a resume or a user goes through esc() before it is put in the page. */
const $ = (id) => document.getElementById(id);

function esc(value) {
  return String(value == null ? "" : value)
    .replace(/&/g, "&amp;").replace(/</g, "&lt;").replace(/>/g, "&gt;")
    .replace(/"/g, "&quot;").replace(/'/g, "&#39;");
}

async function api(url, options) {
  let res;
  try {
    res = await fetch(url, options);
  } catch (e) {
    throw new Error("Could not reach the server. Check your connection and try again.");
  }
  let data = null;
  try { data = await res.json(); } catch (e) { /* not JSON */ }
  if (!res.ok) throw new Error((data && data.error) || "Something went wrong. Please try again.");
  return data;
}

let _meta = null;
async function getMeta() {
  if (!_meta) {
    try { _meta = await api("/api/meta"); } catch (e) { _meta = { roles: [], photo_reading: false, ai: false }; }
  }
  return _meta;
}

function chips(list, cls) {
  return (list || []).map((s) => `<span class="chip ${cls}">${esc(s)}</span>`).join("");
}

function scoreColor(score) {
  return score >= 70 ? "var(--good)" : score >= 50 ? "var(--warn)" : "var(--pen)";
}
