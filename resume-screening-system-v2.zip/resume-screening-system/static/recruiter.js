let chosen = [];
let last = null;

const SAMPLE = `Data Analyst
We are looking for a Data Analyst with strong Python and SQL skills. You will clean and analyze data, build dashboards in Power BI or Tableau, and present insights to stakeholders.
Requirements: Python, pandas, NumPy, SQL, data visualization, statistics, Excel, communication skills. Machine learning basics and Flask are a plus.`;

function renderFiles() {
  $("filelist").innerHTML = chosen.map((f) => `<li>${esc(f.name)}</li>`).join("");
}
function addFiles(list) {
  chosen = chosen.concat([...list]);
  renderFiles();
}
$("files").addEventListener("change", (e) => { addFiles(e.target.files); e.target.value = ""; });
["dragover", "dragenter"].forEach((ev) => $("drop").addEventListener(ev, (e) => { e.preventDefault(); $("drop").classList.add("over"); }));
["dragleave", "drop"].forEach((ev) => $("drop").addEventListener(ev, () => $("drop").classList.remove("over")));
$("drop").addEventListener("drop", (e) => { e.preventDefault(); addFiles(e.dataTransfer.files); });
$("sample").addEventListener("click", () => { $("jd").value = SAMPLE; });

$("form").addEventListener("submit", async (e) => {
  e.preventDefault();
  const err = $("error");
  err.hidden = true;
  const form = new FormData();
  form.append("job_description", $("jd").value);
  form.append("blind", $("blind").checked ? "1" : "0");
  chosen.forEach((f) => form.append("resumes", f));
  const btn = $("go");
  btn.disabled = true;
  btn.textContent = "Ranking...";
  try {
    last = await api("/api/rank", { method: "POST", body: form });
    show(last);
  } catch (ex) {
    err.textContent = ex.message;
    err.hidden = false;
  } finally {
    btn.disabled = false;
    btn.textContent = "Rank resumes";
  }
});

function show(d) {
  let html = `<div class="sheet"><div style="display:flex;justify-content:space-between;align-items:center;gap:12px;flex-wrap:wrap">
    <h2 style="margin:0">${d.count} resume${d.count === 1 ? "" : "s"} ranked${d.blind ? " (names hidden)" : ""}</h2>
    <button class="btn ghost sm" id="csv" type="button">Download CSV</button></div>
    <p class="hint">Match score compares wording with the job post. It does not understand meaning, so read the top resumes yourself and do not reject anyone on the score alone.</p>`;
  html += d.ranking.map((r) => {
    const q = r.quality;
    return `<article class="cand">
      <div class="top2"><span class="rk">#${r.rank}</span>
        <div class="who"><strong>${esc(r.name)}</strong><small>${esc(r.filename)}</small></div>
        <span class="sc">${esc(r.score)}%</span></div>
      <div class="bar" role="img" aria-label="Match ${esc(r.score)} percent"><i style="width:${Math.min(r.score, 100)}%"></i></div>
      ${r.skills_matched.length ? chips(r.skills_matched, "have") : ""}${r.skills_missing.length ? chips(r.skills_missing, "need") : ""}
      ${q ? `<div class="qline">Resume quality <b>${esc(q.score)}/100</b> (${esc(q.label)})${q.from_photo ? ", read from a photo" : ""}</div>
        ${q.issues.length ? `<div class="qissues">Fix: ${q.issues.map(esc).join(", ")}</div>` : ""}` : ""}
    </article>`;
  }).join("");
  html += `</div>`;
  if (d.skipped && d.skipped.length) {
    html += `<div class="callout bad" style="margin-top:16px"><b>Skipped</b>${d.skipped.map((s) => `<div>${esc(s.file)}: ${esc(s.reason)}</div>`).join("")}</div>`;
  }
  $("out").innerHTML = html;
  $("csv").addEventListener("click", downloadCSV);
}

/* CSV values that start with = + - @ can run as formulas in Excel, so they get a leading apostrophe. */
function cell(v) {
  let s = String(v == null ? "" : v);
  if (/^[=+\-@\t\r]/.test(s)) s = "'" + s;
  return '"' + s.replace(/"/g, '""') + '"';
}
function downloadCSV() {
  const head = ["Rank", "Name", "File", "Match %", "Resume quality", "Skills shown", "Skills missing"];
  const rows = last.ranking.map((r) => [r.rank, r.name, r.filename, r.score, r.quality ? r.quality.score : "", r.skills_matched.join("; "), r.skills_missing.join("; ")]);
  const csv = [head, ...rows].map((row) => row.map(cell).join(",")).join("\r\n");
  const a = document.createElement("a");
  a.href = URL.createObjectURL(new Blob(["﻿" + csv], { type: "text/csv;charset=utf-8" }));
  a.download = "resume_ranking.csv";
  document.body.appendChild(a);
  a.click();
  a.remove();
  setTimeout(() => URL.revokeObjectURL(a.href), 2000);
}
