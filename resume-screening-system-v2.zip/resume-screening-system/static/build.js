const EXAMPLE = "My name is Meera Joshi. I am a B.Tech student in Computer Science (AI & Data Science) at a college in Pune, graduating 2027. " +
  "I know Python, SQL, pandas, Power BI and Git. Project: Sales dashboard in Power BI for a local shop using 12,000 sales rows, it cut weekly reporting from 3 hours to 20 minutes. " +
  "Project: Flask web app that ranks resumes. I did a 2 month Python internship in 2025. I want a data analyst role. meera.joshi@example.com 9876543210";

const emptyState = () => ({
  name: "", title: "", email: "", phone: "", location: "", links: [], summary: "", skills: [],
  education: [{ degree: "", school: "", dates: "", detail: "" }],
  experience: [], projects: [{ name: "", tech: "", link: "", bullets: [] }], certifications: [],
});
let state = emptyState();
let timer = null;

/* ---------- tabs ---------- */
function showTab(which) {
  const edit = which === "edit";
  $("tabEdit").setAttribute("aria-selected", edit);
  $("tabDescribe").setAttribute("aria-selected", !edit);
  $("paneEdit").hidden = !edit;
  $("paneDescribe").hidden = edit;
}
$("tabDescribe").addEventListener("click", () => showTab("describe"));
$("tabEdit").addEventListener("click", () => showTab("edit"));

/* ---------- form <-> state ---------- */
const lines = (v) => v.split("\n").map((x) => x.trim()).filter(Boolean);
const skillsToText = (sk) => sk.map((g) => (g.label && g.label !== "Skills" ? g.label + ": " : "") + g.items.join(", ")).join("\n");
function textToSkills(t) {
  return lines(t).map((l) => {
    const i = l.indexOf(":");
    const label = i > 0 ? l.slice(0, i).trim() : "Skills";
    const items = (i > 0 ? l.slice(i + 1) : l).split(",").map((x) => x.trim()).filter(Boolean);
    return { label, items };
  }).filter((g) => g.items.length);
}

function input(label, path, value, opts = {}) {
  const id = "f_" + path.replace(/\./g, "_");
  const kind = opts.kind || "text";
  const ph = opts.ph ? ` placeholder="${esc(opts.ph)}"` : "";
  const control = opts.rows
    ? `<textarea id="${id}" data-path="${esc(path)}" data-kind="${kind}" rows="${opts.rows}"${ph}>${esc(value)}</textarea>`
    : `<input id="${id}" type="text" data-path="${esc(path)}" data-kind="${kind}" value="${esc(value)}"${ph}>`;
  return `<div class="field"><label for="${id}">${esc(label)}</label>${control}${opts.hint ? `<p class="hint">${esc(opts.hint)}</p>` : ""}</div>`;
}

function group(kind, i, title, inner) {
  return `<div class="group"><div class="gh"><span>${esc(title)}</span><button type="button" class="linkbtn small" data-remove="${kind}" data-i="${i}">Remove</button></div>${inner}</div>`;
}

function renderForm() {
  const s = state;
  let h = "";
  h += input("Full name", "name", s.name, { ph: "Meera Joshi" });
  h += input("Target role (shown under your name)", "title", s.title, { ph: "Data Analyst" });
  h += `<div class="row2">${input("Email", "email", s.email, { ph: "name@example.com" })}${input("Phone", "phone", s.phone, { ph: "98765 43210" })}</div>`;
  h += input("City", "location", s.location, { ph: "Pune, Maharashtra" });
  h += input("Links (one per line)", "links", s.links.join("\n"), { kind: "lines", rows: 2, ph: "github.com/yourname\nlinkedin.com/in/yourname" });
  h += input("Summary (2 short lines)", "summary", s.summary, { rows: 3, ph: "Data analyst fresher with project experience in Python and SQL." });
  h += input("Skills (one line per group)", "skills", skillsToText(s.skills), { kind: "skills", rows: 3, ph: "Languages: Python, SQL\nTools: Git, Power BI, Excel", hint: "Write 'Label: item, item'. Only list skills you really have." });

  h += `<h3 style="margin-top:18px">Education</h3>`;
  s.education.forEach((e, i) => {
    h += group("education", i, `Education ${i + 1}`,
      input("Degree", `education.${i}.degree`, e.degree, { ph: "B.Tech in Computer Science" }) +
      input("College", `education.${i}.school`, e.school, { ph: "Your college, city" }) +
      `<div class="row2">${input("Years", `education.${i}.dates`, e.dates, { ph: "2023 - 2027" })}${input("Score (optional)", `education.${i}.detail`, e.detail, { ph: "CGPA 8.1" })}</div>`);
  });
  h += `<button type="button" class="btn ghost sm" data-add="education">Add education</button>`;

  h += `<h3 style="margin-top:18px">Projects</h3>`;
  s.projects.forEach((p, i) => {
    h += group("projects", i, `Project ${i + 1}`,
      input("Name", `projects.${i}.name`, p.name, { ph: "Sales dashboard" }) +
      input("Tools used", `projects.${i}.tech`, p.tech, { ph: "Power BI, SQL" }) +
      input("Link (optional)", `projects.${i}.link`, p.link, { ph: "github.com/you/project" }) +
      input("What you did (one point per line)", `projects.${i}.bullets`, p.bullets.join("\n"), { kind: "lines", rows: 4, ph: "Built a dashboard on 12,000 rows...", hint: "Start with a verb and add a real number if you have one." }));
  });
  h += `<button type="button" class="btn ghost sm" data-add="projects">Add project</button>`;

  h += `<h3 style="margin-top:18px">Experience or internships</h3>`;
  s.experience.forEach((x, i) => {
    h += group("experience", i, `Experience ${i + 1}`,
      input("Role", `experience.${i}.role`, x.role, { ph: "Python Intern" }) +
      `<div class="row2">${input("Company", `experience.${i}.company`, x.company, { ph: "Company name" })}${input("Dates", `experience.${i}.dates`, x.dates, { ph: "May 2025 - Jun 2025" })}</div>` +
      input("What you did (one point per line)", `experience.${i}.bullets`, x.bullets.join("\n"), { kind: "lines", rows: 4 }));
  });
  h += `<button type="button" class="btn ghost sm" data-add="experience">Add experience</button>`;

  h += `<h3 style="margin-top:18px">Certifications</h3>`;
  h += input("One per line", "certifications", s.certifications.join("\n"), { kind: "lines", rows: 3, ph: "Python for Data Science, NPTEL" });
  $("editForm").innerHTML = h;
}

$("editForm").addEventListener("input", (e) => {
  const el = e.target;
  const path = el.dataset.path;
  if (!path) return;
  let val = el.value;
  if (el.dataset.kind === "lines") val = lines(val);
  if (el.dataset.kind === "skills") val = textToSkills(val);
  const parts = path.split(".");
  let o = state;
  for (let i = 0; i < parts.length - 1; i++) o = o[parts[i]];
  o[parts[parts.length - 1]] = val;
  schedulePreview();
});

$("editForm").addEventListener("click", (e) => {
  const add = e.target.dataset.add, rem = e.target.dataset.remove;
  if (add) {
    state[add].push(add === "education" ? { degree: "", school: "", dates: "", detail: "" }
      : add === "projects" ? { name: "", tech: "", link: "", bullets: [] }
      : { role: "", company: "", dates: "", bullets: [] });
    renderForm();
  } else if (rem) {
    state[rem].splice(Number(e.target.dataset.i), 1);
    renderForm();
    schedulePreview();
  }
});

/* ---------- preview ---------- */
const style = () => $("style").value;
function schedulePreview() {
  clearTimeout(timer);
  timer = setTimeout(refreshPreview, 350);
}
async function refreshPreview() {
  try {
    const res = await api("/api/build/preview", { method: "POST", headers: { "Content-Type": "application/json" }, body: JSON.stringify({ resume: state, style: style() }) });
    $("preview").innerHTML = res.html;
    $("warn").textContent = $("preview").querySelector("mark.todo") ? "Highlighted [brackets] still need your real details." : "";
  } catch (e) {
    $("preview").innerHTML = `<p class="error">${esc(e.message)}</p>`;
  }
}
$("style").addEventListener("change", refreshPreview);

/* ---------- drafts ---------- */
$("example").addEventListener("click", () => { $("prompt").value = EXAMPLE; });

async function draft(useAI) {
  const err = $("draftErr"), msg = $("draftMsg");
  err.hidden = true; msg.hidden = true;
  const btn = useAI ? $("aiDraft") : $("basicDraft");
  const old = btn.textContent;
  btn.disabled = true;
  btn.textContent = "Working...";
  try {
    const res = await api("/api/build/draft", { method: "POST", headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ prompt: $("prompt").value, style: style(), use_ai: useAI }) });
    state = Object.assign(emptyState(), res.resume);
    if (!state.education.length) state.education = emptyState().education;
    renderForm();
    refreshPreview();
    msg.textContent = res.mode === "ai"
      ? "Written by AI from your description. Read every line and replace each [bracket] with a real detail. Remove anything that is not true."
      : "Basic draft. We filled what we could find. Open Edit details to complete the [brackets].";
    msg.hidden = false;
  } catch (e) {
    err.textContent = e.message;
    err.hidden = false;
  } finally {
    btn.disabled = false;
    btn.textContent = old;
  }
}
$("aiDraft").addEventListener("click", () => draft(true));
$("basicDraft").addEventListener("click", () => draft(false));

/* ---------- downloads ---------- */
$("docx").addEventListener("click", async () => {
  const btn = $("docx");
  btn.disabled = true;
  try {
    const res = await fetch("/api/build/docx", { method: "POST", headers: { "Content-Type": "application/json" }, body: JSON.stringify({ resume: state, style: style() }) });
    if (!res.ok) throw new Error("Could not create the file. Try again.");
    const blob = await res.blob();
    const a = document.createElement("a");
    a.href = URL.createObjectURL(blob);
    a.download = (state.name || "resume").replace(/[^\w -]/g, "").trim().replace(/ +/g, "_") + "_resume.docx";
    document.body.appendChild(a);
    a.click();
    a.remove();
    setTimeout(() => URL.revokeObjectURL(a.href), 2000);
  } catch (e) {
    $("warn").textContent = e.message;
  } finally {
    btn.disabled = false;
  }
});
$("print").addEventListener("click", () => window.print());

/* ---------- start ---------- */
getMeta().then((m) => {
  if (!m.ai) {
    $("aiDraft").disabled = true;
    $("aiNote").textContent = "AI writing is not connected on this server. Use the basic draft or Edit details.";
  } else {
    $("aiNote").textContent = "Sends what you wrote to the AI service. It is told not to invent facts, but check every line.";
  }
});
renderForm();
refreshPreview();
